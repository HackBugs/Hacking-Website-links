"""
ui.common
---------
Shared building blocks used by every tool page: output-folder/naming
options (spec 27/28), and the Start/Cancel/progress bar that drives a
BatchWorker (spec 25/26).
"""
from __future__ import annotations

import os
from typing import Callable, Optional

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGroupBox, QFormLayout, QLineEdit,
    QPushButton, QFileDialog, QComboBox, QProgressBar, QLabel, QMessageBox,
    QPlainTextEdit, QDialog, QDialogButtonBox,
)

from core.worker import BatchWorker, BatchSummary
from core.file_utils import unique_output_path


class OutputOptionsWidget(QGroupBox):
    def __init__(self, settings, parent=None):
        super().__init__("Output", parent)
        self._settings = settings
        form = QFormLayout(self)

        row = QHBoxLayout()
        self.output_folder = QLineEdit(settings.settings.default_output_folder)
        browse = QPushButton("Browse…")
        browse.clicked.connect(self._browse)
        row.addWidget(self.output_folder)
        row.addWidget(browse)
        form.addRow("Output folder:", row)

        self.overwrite_policy = QComboBox()
        self.overwrite_policy.addItems(["Rename", "Overwrite", "Skip", "Ask"])
        self.overwrite_policy.setCurrentText(settings.settings.overwrite_policy)
        form.addRow("If file exists:", self.overwrite_policy)

        self.naming_template = QLineEdit("{name}")
        self.naming_template.setToolTip("Tokens: {index} {name} {date}. Example: {index}_{name}")
        form.addRow("Naming template:", self.naming_template)

        self.create_subfolder = QComboBox()
        self.create_subfolder.addItems(["Same as output folder", "Create dated subfolder"])
        form.addRow("Subfolder:", self.create_subfolder)

    def _browse(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Select output folder", self.output_folder.text())
        if folder:
            self.output_folder.setText(folder)

    def resolved_folder(self) -> str:
        base = self.output_folder.text().strip() or self._settings.settings.default_output_folder
        if self.create_subfolder.currentIndex() == 1:
            import datetime
            base = os.path.join(base, datetime.datetime.now().strftime("%Y%m%d_%H%M%S"))
        os.makedirs(base, exist_ok=True)
        return base

    def resolve_output_path(self, folder: str, filename: str) -> Optional[str]:
        target = os.path.join(folder, filename)
        policy = self.overwrite_policy.currentText()
        if policy == "Ask" and os.path.exists(target):
            resp = QMessageBox.question(self, "File exists", f"{filename} already exists. Overwrite?")
            policy = "Overwrite" if resp == QMessageBox.Yes else "Skip"
        return unique_output_path(target, policy)


class ErrorSummaryDialog(QDialog):
    def __init__(self, summary: BatchSummary, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Batch results")
        self.resize(560, 360)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(
            f"Completed: {summary.completed}    Failed: {summary.failed}    Skipped: {summary.skipped}"
        ))
        text = QPlainTextEdit()
        text.setReadOnly(True)
        lines = [f"[{r.status}] {r.file_name}" + (f" — {r.message}" if r.message else "") for r in summary.results]
        text.setPlainText("\n".join(lines))
        layout.addWidget(text)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok)
        buttons.accepted.connect(self.accept)
        layout.addWidget(buttons)


class RunControlsWidget(QWidget):
    """Progress bar + Start/Cancel, wired to a BatchWorker."""

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        self.progress = QProgressBar()
        self.status_label = QLabel("Idle")
        self.btn_start = QPushButton("Start (Ctrl+Enter)")
        self.btn_cancel = QPushButton("Cancel (Esc)")
        self.btn_cancel.setEnabled(False)
        layout.addWidget(self.status_label, 1)
        layout.addWidget(self.progress, 3)
        layout.addWidget(self.btn_start)
        layout.addWidget(self.btn_cancel)

        self._worker: Optional[BatchWorker] = None
        self.btn_cancel.clicked.connect(self._cancel)

    def _cancel(self) -> None:
        if self._worker:
            self._worker.cancel()
            self.status_label.setText("Cancelling…")

    def run_jobs(self, jobs: list[tuple[str, Callable[[], object]]],
                 on_finished: Callable[[BatchSummary], None]) -> None:
        if not jobs:
            QMessageBox.information(self, "Nothing to do", "Add some files first.")
            return
        self.progress.setMaximum(len(jobs))
        self.progress.setValue(0)
        self.btn_start.setEnabled(False)
        self.btn_cancel.setEnabled(True)
        self.status_label.setText("Starting…")

        self._worker = BatchWorker(jobs)
        self._worker.progress.connect(self._on_progress)

        def _finish(summary: BatchSummary) -> None:
            self.btn_start.setEnabled(True)
            self.btn_cancel.setEnabled(False)
            self.status_label.setText(
                f"Done — Completed {summary.completed}, Failed {summary.failed}, Skipped {summary.skipped}"
            )
            on_finished(summary)

        self._worker.finished_summary.connect(_finish)
        self._worker.start()

    def _on_progress(self, done: int, total: int, label: str) -> None:
        self.progress.setMaximum(total)
        self.progress.setValue(done)
        self.status_label.setText(f"Processing {done}/{total}: {label}")
