"""
ui.pages_extra
---------------
Watermark (15), Advanced command builder (21/32/37), Home dashboard, History
(29) and Settings (30) pages.
"""
from __future__ import annotations

import os
import shlex
import subprocess

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGroupBox, QFormLayout, QComboBox,
    QSpinBox, QSlider, QLineEdit, QPushButton, QFileDialog, QLabel,
    QColorDialog, QMessageBox, QPlainTextEdit, QTableWidget, QTableWidgetItem,
    QHeaderView, QCheckBox,
)

from ui.common import OutputOptionsWidget, RunControlsWidget, ErrorSummaryDialog
from core.file_utils import render_name_template
from core.imagemagick_service import sanitize_custom_args
from core.settings_service import logs_dir


POSITIONS = {
    "Top left": "northwest", "Top center": "north", "Top right": "northeast",
    "Center": "center", "Bottom left": "southwest", "Bottom center": "south",
    "Bottom right": "southeast",
}


# ------------------------------------------------------------------ Watermark
class WatermarkPage(QWidget):
    title = "Watermark & Text"

    def __init__(self, batch_widget, magick, settings, history, parent=None):
        super().__init__(parent)
        self.batch_widget = batch_widget
        self.magick = magick
        self.settings = settings
        self.history = history
        self._color = "#FFFFFF"

        root = QVBoxLayout(self)
        root.addWidget(QLabel("<h2>Watermark</h2>"))

        self.kind = QComboBox(); self.kind.addItems(["Text watermark", "Image/logo watermark"])
        root.addWidget(self.kind)

        text_box = QGroupBox("Text options")
        tform = QFormLayout(text_box)
        self.text_value = QLineEdit("© Your Company")
        self.font_size = QSpinBox(); self.font_size.setRange(4, 400); self.font_size.setValue(36)
        self.color_btn = QPushButton("Choose color…")
        self.color_btn.clicked.connect(self._choose_color)
        self.rotation = QSpinBox(); self.rotation.setRange(-180, 180)
        tform.addRow("Text:", self.text_value)
        tform.addRow("Font size:", self.font_size)
        tform.addRow("Color:", self.color_btn)
        tform.addRow("Rotation:", self.rotation)
        root.addWidget(text_box)

        logo_box = QGroupBox("Logo options")
        lform = QFormLayout(logo_box)
        self.logo_path = QLineEdit()
        logo_browse = QPushButton("Browse…")
        logo_browse.clicked.connect(self._browse_logo)
        lrow = QHBoxLayout(); lrow.addWidget(self.logo_path); lrow.addWidget(logo_browse)
        self.logo_scale = QSpinBox(); self.logo_scale.setRange(1, 100); self.logo_scale.setValue(20); self.logo_scale.setSuffix("%")
        lform.addRow("Logo file:", lrow)
        lform.addRow("Scale (% of image width):", self.logo_scale)
        root.addWidget(logo_box)

        common_box = QGroupBox("Placement")
        cform = QFormLayout(common_box)
        self.position = QComboBox(); self.position.addItems(list(POSITIONS.keys()))
        self.opacity = QSlider(Qt.Horizontal); self.opacity.setRange(1, 100); self.opacity.setValue(60)
        self.margin = QSpinBox(); self.margin.setRange(0, 500); self.margin.setValue(20)
        cform.addRow("Position:", self.position)
        cform.addRow("Opacity:", self.opacity)
        cform.addRow("Margin (px):", self.margin)
        root.addWidget(common_box)

        self.output_options = OutputOptionsWidget(settings)
        self.output_options.naming_template.setText("{name}_wm")
        root.addWidget(self.output_options)

        self.run_controls = RunControlsWidget()
        self.run_controls.btn_start.clicked.connect(self.start)
        root.addWidget(self.run_controls)
        root.addStretch()

    def _choose_color(self) -> None:
        c = QColorDialog.getColor()
        if c.isValid():
            self._color = c.name()
            self.color_btn.setText(f"Color: {self._color}")

    def _browse_logo(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Select logo", "", "Images (*.png *.jpg *.jpeg *.webp)")
        if path:
            self.logo_path.setText(path)

    def start(self) -> None:
        files = self.batch_widget.file_paths()
        if not files:
            QMessageBox.information(self, "Nothing to do", "Add some images first.")
            return
        folder = self.output_options.resolved_folder()
        is_text = self.kind.currentText().startswith("Text")
        gravity = POSITIONS[self.position.currentText()]
        geometry = f"+{self.margin.value()}+{self.margin.value()}"

        jobs = []
        for idx, src in enumerate(files, start=1):
            base = os.path.basename(src)
            stem, ext = os.path.splitext(base)
            template = self.output_options.naming_template.text() or "{name}_wm"
            new_stem = render_name_template(template, idx, base)
            dst = self.output_options.resolve_output_path(folder, new_stem + ext)

            def make_job(s=src, d=dst, label=base):
                def _job():
                    if d is None:
                        return "skipped"
                    if is_text:
                        args = [
                            "convert", s, "-gravity", gravity,
                            "-pointsize", str(self.font_size.value()),
                            "-fill", self._color,
                            "-annotate", f"{self.rotation.value()}x{self.rotation.value()}{geometry}",
                            self.text_value.text(), d,
                        ]
                        res = self.magick.run(args)
                    else:
                        logo = self.logo_path.text().strip()
                        if not logo or not os.path.isfile(logo):
                            raise RuntimeError("No logo file selected.")
                        args = [
                            "composite", "-gravity", gravity, "-geometry",
                            f"{self.logo_scale.value()}%x+{self.margin.value()}+{self.margin.value()}",
                            "-dissolve", str(self.opacity.value()),
                            logo, s, d,
                        ]
                        res = self.magick.run(args)
                    if not res.ok:
                        raise RuntimeError(res.stderr.strip() or "watermark failed")
                    return "ok"
                return label, _job
            jobs.append(make_job())

        def finished(summary):
            ErrorSummaryDialog(summary, self).exec()
            self.history.add(self.title, f"{len(files)} file(s)", folder,
                              {"kind": self.kind.currentText(), "position": self.position.currentText()},
                              summary.completed, summary.failed, summary.skipped)

        self.run_controls.run_jobs(jobs, finished)


# --------------------------------------------------------------------- Advanced
class AdvancedPage(QWidget):
    title = "Advanced ImageMagick"

    def __init__(self, batch_widget, magick, settings, history, parent=None):
        super().__init__(parent)
        self.batch_widget = batch_widget
        self.magick = magick
        self.settings = settings
        self.history = history

        root = QVBoxLayout(self)
        root.addWidget(QLabel("<h2>Advanced ImageMagick Command Builder</h2>"))
        warn = QLabel(
            "For advanced users. Custom arguments run through a safe argument list "
            "(no shell interpretation) — shell metacharacters like &&, |, ; and $() are "
            "stripped automatically. This still runs real ImageMagick commands: double-check "
            "before running on important files."
        )
        warn.setWordWrap(True)
        warn.setStyleSheet("color: #b45309;")
        root.addWidget(warn)

        box = QGroupBox("Command")
        form = QFormLayout(box)
        self.custom_args = QLineEdit("-auto-orient -resize 1600x1600 -quality 85")
        form.addRow("Custom arguments (after 'magick convert <input>'):", self.custom_args)
        self.output_ext = QComboBox(); self.output_ext.addItems([".jpg", ".png", ".webp", ".tiff", ".pdf"])
        form.addRow("Output extension:", self.output_ext)
        root.addWidget(box)

        preview_row = QHBoxLayout()
        self.preview_label = QLineEdit()
        self.preview_label.setReadOnly(True)
        copy_btn = QPushButton("Copy command")
        copy_btn.clicked.connect(self._copy_command)
        preview_row.addWidget(self.preview_label)
        preview_row.addWidget(copy_btn)
        root.addWidget(QLabel("Generated command (example, first file in queue):"))
        root.addLayout(preview_row)

        self.custom_args.textChanged.connect(self._update_preview)
        self.output_ext.currentTextChanged.connect(self._update_preview)
        self._update_preview()

        self.output_options = OutputOptionsWidget(settings)
        self.output_options.naming_template.setText("{name}_advanced")
        root.addWidget(self.output_options)

        self.run_controls = RunControlsWidget()
        self.run_controls.btn_start.clicked.connect(self.start)
        root.addWidget(self.run_controls)

        root.addWidget(QLabel("Log:"))
        self.log_view = QPlainTextEdit(); self.log_view.setReadOnly(True); self.log_view.setMaximumHeight(140)
        root.addWidget(self.log_view)

    def _example_src(self) -> str:
        files = self.batch_widget.file_paths()
        return files[0] if files else "input.jpg"

    def _update_preview(self) -> None:
        args, warnings = sanitize_custom_args(self.custom_args.text())
        cmd = ["magick", "convert", self._example_src(), *args, f"output{self.output_ext.currentText()}"]
        self.preview_label.setText(" ".join(shlex.quote(a) for a in cmd))
        if warnings:
            self.log_view_warn(warnings)

    def log_view_warn(self, warnings: list[str]) -> None:
        if hasattr(self, "log_view"):
            for w in warnings:
                self.log_view.appendPlainText(f"[warning] {w}")

    def _copy_command(self) -> None:
        from PySide6.QtWidgets import QApplication
        QApplication.clipboard().setText(self.preview_label.text())

    def start(self) -> None:
        files = self.batch_widget.file_paths()
        if not files:
            QMessageBox.information(self, "Nothing to do", "Add some images first.")
            return
        folder = self.output_options.resolved_folder()
        args, warnings = sanitize_custom_args(self.custom_args.text())
        for w in warnings:
            self.log_view.appendPlainText(f"[warning] {w}")

        jobs = []
        for idx, src in enumerate(files, start=1):
            base = os.path.basename(src)
            template = self.output_options.naming_template.text() or "{name}_advanced"
            new_stem = render_name_template(template, idx, base)
            dst = self.output_options.resolve_output_path(folder, new_stem + self.output_ext.currentText())

            def make_job(s=src, d=dst, label=base):
                def _job():
                    if d is None:
                        return "skipped"
                    full_args = ["convert", s, *args, d]
                    res = self.magick.run(full_args)
                    self.log_view.appendPlainText(f"$ magick {' '.join(full_args)}")
                    if res.stderr:
                        self.log_view.appendPlainText(res.stderr.strip())
                    if not res.ok:
                        raise RuntimeError(res.stderr.strip() or f"exit code {res.exit_code}")
                    return "ok"
                return label, _job
            jobs.append(make_job())

        def finished(summary):
            ErrorSummaryDialog(summary, self).exec()
            self.history.add(self.title, f"{len(files)} file(s)", folder, {"args": args},
                              summary.completed, summary.failed, summary.skipped)

        self.run_controls.run_jobs(jobs, finished)


# ------------------------------------------------------------------------ Home
class HomePage(QWidget):
    title = "Home"

    def __init__(self, magick, settings, on_navigate, parent=None):
        super().__init__(parent)
        self.magick = magick
        self.settings = settings
        root = QVBoxLayout(self)
        root.addWidget(QLabel("<h1>ImageMagick GUI Suite</h1>"))
        root.addWidget(QLabel(
            "A graphical alternative to ImageMagick command-line usage: batch convert, resize, "
            "crop, rotate, compress, adjust, watermark, filter, and build PDFs — with no CMD "
            "knowledge required."
        ))

        self.status_box = QGroupBox("ImageMagick backend")
        sform = QFormLayout(self.status_box)
        self.status_label = QLabel()
        self.path_label = QLabel()
        sform.addRow("Status:", self.status_label)
        sform.addRow("Executable:", self.path_label)
        btn_row = QHBoxLayout()
        detect_btn = QPushButton("Auto-detect")
        detect_btn.clicked.connect(self.detect)
        browse_btn = QPushButton("Select executable manually…")
        browse_btn.clicked.connect(self.browse)
        btn_row.addWidget(detect_btn); btn_row.addWidget(browse_btn)
        sform.addRow(btn_row)
        root.addWidget(self.status_box)

        quick = QGroupBox("Quick start")
        qlayout = QVBoxLayout(quick)
        for label, key in [
            ("Batch Converter", "Batch Converter"), ("PDF Tools", "PDF Tools"),
            ("Resize", "Resize"), ("Compression", "Compression"),
        ]:
            b = QPushButton(f"Open {label}")
            b.clicked.connect(lambda _=False, k=key: on_navigate(k))
            qlayout.addWidget(b)
        root.addWidget(quick)
        root.addStretch()

        self.refresh()

    def refresh(self) -> None:
        if self.magick.is_ready:
            self.status_label.setText("✅ Ready")
            self.path_label.setText(self.magick.path or "-")
        else:
            self.status_label.setText("⚠️ Not configured")
            self.path_label.setText("-")

    def detect(self) -> None:
        info = self.magick.autodetect()
        if info.ok:
            self.settings.update(magick_path=info.path)
            QMessageBox.information(self, "Detected", f"Found ImageMagick {info.version} at:\n{info.path}")
        else:
            QMessageBox.warning(self, "Not found", info.error or "ImageMagick was not found.")
        self.refresh()

    def browse(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Select magick executable", "",
                                               "magick executable (magick.exe magick)")
        if not path:
            return
        info = self.magick.set_path(path)
        if info.ok:
            self.settings.update(magick_path=path)
            QMessageBox.information(self, "OK", f"ImageMagick {info.version} configured.")
        else:
            QMessageBox.warning(self, "Invalid", info.error or "That file did not work as an ImageMagick executable.")
        self.refresh()


# --------------------------------------------------------------------- History
class HistoryPage(QWidget):
    title = "History"

    def __init__(self, history_service, parent=None):
        super().__init__(parent)
        self.history_service = history_service
        root = QVBoxLayout(self)
        root.addWidget(QLabel("<h2>History</h2>"))

        top = QHBoxLayout()
        refresh_btn = QPushButton("Refresh")
        refresh_btn.clicked.connect(self.reload)
        clear_btn = QPushButton("Clear history")
        clear_btn.clicked.connect(self.clear)
        top.addWidget(refresh_btn); top.addWidget(clear_btn); top.addStretch()
        root.addLayout(top)

        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["Date/Time", "Operation", "Input", "Output", "Result", "Settings"])
        self.table.horizontalHeader().setSectionResizeMode(5, QHeaderView.Stretch)
        root.addWidget(self.table)
        self.reload()

    def reload(self) -> None:
        import datetime
        entries = self.history_service.list()
        self.table.setRowCount(0)
        for e in entries:
            row = self.table.rowCount()
            self.table.insertRow(row)
            when = datetime.datetime.fromtimestamp(e.timestamp).strftime("%Y-%m-%d %H:%M:%S")
            self.table.setItem(row, 0, QTableWidgetItem(when))
            self.table.setItem(row, 1, QTableWidgetItem(e.operation))
            self.table.setItem(row, 2, QTableWidgetItem(e.input_summary))
            self.table.setItem(row, 3, QTableWidgetItem(e.output_summary))
            self.table.setItem(row, 4, QTableWidgetItem(f"OK {e.completed} / Failed {e.failed} / Skipped {e.skipped}"))
            self.table.setItem(row, 5, QTableWidgetItem(str(e.settings)))

    def clear(self) -> None:
        if QMessageBox.question(self, "Clear history", "Remove all history entries?") == QMessageBox.Yes:
            self.history_service.clear()
            self.reload()


# -------------------------------------------------------------------- Settings
class SettingsPage(QWidget):
    title = "Settings"

    def __init__(self, magick, settings, parent=None):
        super().__init__(parent)
        self.magick = magick
        self.settings = settings
        s = settings.settings

        root = QVBoxLayout(self)
        root.addWidget(QLabel("<h2>Settings</h2>"))
        form = QFormLayout()

        self.magick_path = QLineEdit(s.magick_path or "")
        browse = QPushButton("Browse…"); browse.clicked.connect(self._browse_magick)
        test = QPushButton("Test"); test.clicked.connect(self._test_magick)
        row = QHBoxLayout(); row.addWidget(self.magick_path); row.addWidget(browse); row.addWidget(test)
        form.addRow("ImageMagick executable:", row)

        self.output_folder = QLineEdit(s.default_output_folder)
        out_browse = QPushButton("Browse…"); out_browse.clicked.connect(self._browse_output)
        orow = QHBoxLayout(); orow.addWidget(self.output_folder); orow.addWidget(out_browse)
        form.addRow("Default output folder:", orow)

        self.pdf_dpi = QSpinBox(); self.pdf_dpi.setRange(50, 1200); self.pdf_dpi.setValue(s.default_pdf_dpi)
        form.addRow("Default PDF DPI:", self.pdf_dpi)

        self.jpeg_quality = QSpinBox(); self.jpeg_quality.setRange(1, 100); self.jpeg_quality.setValue(s.default_jpeg_quality)
        form.addRow("Default JPEG quality:", self.jpeg_quality)

        self.page_size = QComboBox(); self.page_size.addItems(["A4", "A3", "A5", "Letter", "Legal", "Custom"])
        self.page_size.setCurrentText(s.default_pdf_page_size)
        form.addRow("Default PDF page size:", self.page_size)

        self.orientation = QComboBox(); self.orientation.addItems(["AUTO", "PORTRAIT", "LANDSCAPE"])
        self.orientation.setCurrentText(s.default_pdf_orientation)
        form.addRow("Default PDF orientation:", self.orientation)

        self.theme = QComboBox(); self.theme.addItems(["System", "Light", "Dark"])
        self.theme.setCurrentText(s.theme)
        form.addRow("Theme:", self.theme)

        self.workers = QSpinBox(); self.workers.setRange(1, 32); self.workers.setValue(s.max_parallel_workers)
        form.addRow("Max parallel workers:", self.workers)

        self.temp_folder = QLineEdit(s.temp_folder)
        form.addRow("Temporary folder:", self.temp_folder)

        self.logging_level = QComboBox(); self.logging_level.addItems(["DEBUG", "INFO", "WARNING", "ERROR"])
        self.logging_level.setCurrentText(s.logging_level)
        form.addRow("Logging level:", self.logging_level)

        self.recursive = QCheckBox("Scan folders recursively by default")
        self.recursive.setChecked(s.recursive_folder_scan)
        form.addRow(self.recursive)

        root.addLayout(form)

        btn_row = QHBoxLayout()
        save_btn = QPushButton("Save settings"); save_btn.clicked.connect(self.save)
        logs_btn = QPushButton("Open logs folder"); logs_btn.clicked.connect(self._open_logs)
        btn_row.addWidget(save_btn); btn_row.addWidget(logs_btn); btn_row.addStretch()
        root.addLayout(btn_row)
        root.addStretch()

    def _browse_magick(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Select magick executable")
        if path:
            self.magick_path.setText(path)

    def _test_magick(self) -> None:
        info = self.magick.set_path(self.magick_path.text().strip())
        if info.ok:
            QMessageBox.information(self, "OK", f"ImageMagick {info.version} works correctly.")
        else:
            QMessageBox.warning(self, "Failed", info.error or "Could not use that executable.")

    def _browse_output(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Default output folder", self.output_folder.text())
        if folder:
            self.output_folder.setText(folder)

    def _open_logs(self) -> None:
        path = logs_dir()
        if os.name == "nt":
            os.startfile(path)  # type: ignore[attr-defined]
        else:
            subprocess.run(["xdg-open", path], check=False)

    def save(self) -> None:
        self.settings.update(
            magick_path=self.magick_path.text().strip() or None,
            default_output_folder=self.output_folder.text().strip(),
            default_pdf_dpi=self.pdf_dpi.value(),
            default_jpeg_quality=self.jpeg_quality.value(),
            default_pdf_page_size=self.page_size.currentText(),
            default_pdf_orientation=self.orientation.currentText(),
            theme=self.theme.currentText(),
            max_parallel_workers=self.workers.value(),
            temp_folder=self.temp_folder.text().strip(),
            logging_level=self.logging_level.currentText(),
            recursive_folder_scan=self.recursive.isChecked(),
        )
        QMessageBox.information(self, "Saved", "Settings saved.")
