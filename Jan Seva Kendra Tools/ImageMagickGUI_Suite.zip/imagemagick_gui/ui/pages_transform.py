"""
ui.pages_transform
-------------------
Resize, Crop, Rotate/Flip, Compression, Adjustments and Filters pages
(spec sections 9-14, 17). Each page: pick options -> Start -> a BatchWorker
runs one `magick` invocation per file in the shared batch queue.
"""
from __future__ import annotations

import os
from typing import Callable

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGroupBox, QFormLayout, QComboBox,
    QSpinBox, QCheckBox, QLabel, QSlider, QPushButton,
)

from ui.common import OutputOptionsWidget, RunControlsWidget, ErrorSummaryDialog
from core.file_utils import render_name_template


class ToolPageBase(QWidget):
    """Shared scaffolding: batch table (injected), output options, run controls."""

    title = "Tool"
    default_suffix = ""

    def __init__(self, batch_widget, magick, settings, history, parent=None):
        super().__init__(parent)
        self.batch_widget = batch_widget
        self.magick = magick
        self.settings = settings
        self.history = history

        self.root = QVBoxLayout(self)
        self.root.addWidget(QLabel(f"<h2>{self.title}</h2>"))
        self.options_box = QGroupBox("Options")
        self.options_form = QFormLayout(self.options_box)
        self.root.addWidget(self.options_box)

        self.output_options = OutputOptionsWidget(settings)
        self.output_options.naming_template.setText("{name}" + self.default_suffix)
        self.root.addWidget(self.output_options)

        self.run_controls = RunControlsWidget()
        self.run_controls.btn_start.clicked.connect(self.start)
        self.root.addWidget(self.run_controls)
        self.root.addStretch()

    # override in subclasses
    def build_args(self, src: str, dst: str) -> list[str]:
        raise NotImplementedError

    def start(self) -> None:
        files = self.batch_widget.file_paths()
        folder = self.output_options.resolved_folder()
        jobs: list[tuple[str, Callable[[], object]]] = []

        for idx, src in enumerate(files, start=1):
            base = os.path.basename(src)
            stem, ext = os.path.splitext(base)
            template = self.output_options.naming_template.text() or "{name}"
            new_stem = render_name_template(template, idx, base, width=3)
            dst_name = new_stem + (ext if not new_stem.lower().endswith(ext.lower()) else "")
            dst_path = self.output_options.resolve_output_path(folder, dst_name)

            def make_job(s=src, d=dst_path, label=base):
                def _job():
                    if d is None:
                        return "skipped"
                    args = self.build_args(s, d)
                    res = self.magick.run(args)
                    if not res.ok:
                        raise RuntimeError(res.stderr.strip() or f"exit code {res.exit_code}")
                    return "ok"
                return label, _job

            jobs.append(make_job())

        def finished(summary):
            ErrorSummaryDialog(summary, self).exec()
            self.history.add(self.title, f"{len(files)} file(s)", folder,
                              self.current_settings_dict(), summary.completed, summary.failed, summary.skipped)

        self.run_controls.run_jobs(jobs, finished)

    def current_settings_dict(self) -> dict:
        return {}


# --------------------------------------------------------------------- Resize
class ResizePage(ToolPageBase):
    title = "Resize"
    default_suffix = "_resized"

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.mode = QComboBox()
        self.mode.addItems(["Exact dimensions", "Maximum dimensions", "Minimum dimensions", "Percentage"])
        self.width = QSpinBox(); self.width.setRange(1, 20000); self.width.setValue(1600)
        self.height = QSpinBox(); self.height.setRange(1, 20000); self.height.setValue(1600)
        self.percentage = QSpinBox(); self.percentage.setRange(1, 1000); self.percentage.setValue(50); self.percentage.setSuffix("%")
        self.preserve_aspect = QCheckBox("Preserve aspect ratio"); self.preserve_aspect.setChecked(True)
        self.allow_upscale = QCheckBox("Allow upscaling")
        self.filter_combo = QComboBox(); self.filter_combo.addItems(["Lanczos", "Mitchell", "Bicubic", "Catrom", "Nearest"])

        self.options_form.addRow("Mode:", self.mode)
        self.options_form.addRow("Width:", self.width)
        self.options_form.addRow("Height:", self.height)
        self.options_form.addRow("Percentage:", self.percentage)
        self.options_form.addRow(self.preserve_aspect)
        self.options_form.addRow(self.allow_upscale)
        self.options_form.addRow("Filter:", self.filter_combo)

    def build_args(self, src, dst):
        mode = self.mode.currentText()
        args = ["convert", src, "-filter", self.filter_combo.currentText()]
        if mode == "Percentage":
            geom = f"{self.percentage.value()}%"
        else:
            w, h = self.width.value(), self.height.value()
            geom = f"{w}x{h}"
            if not self.preserve_aspect.isChecked():
                geom += "!"
            elif mode == "Minimum dimensions":
                geom += "^"
        if not self.allow_upscale.isChecked() and mode != "Percentage":
            geom += ">"
        args += ["-resize", geom, dst]
        return args

    def current_settings_dict(self):
        return {"mode": self.mode.currentText(), "width": self.width.value(), "height": self.height.value(),
                "percentage": self.percentage.value(), "filter": self.filter_combo.currentText()}


# ----------------------------------------------------------------------- Crop
class CropPage(ToolPageBase):
    title = "Crop"
    default_suffix = "_cropped"

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.preset = QComboBox()
        self.preset.addItems(["Custom", "1:1", "4:3", "16:9", "A4", "3:2", "Center crop"])
        self.width = QSpinBox(); self.width.setRange(1, 20000); self.width.setValue(800)
        self.height = QSpinBox(); self.height.setRange(1, 20000); self.height.setValue(800)
        self.x = QSpinBox(); self.x.setRange(0, 20000)
        self.y = QSpinBox(); self.y.setRange(0, 20000)

        self.options_form.addRow("Preset:", self.preset)
        self.options_form.addRow("Width:", self.width)
        self.options_form.addRow("Height:", self.height)
        self.options_form.addRow("X offset:", self.x)
        self.options_form.addRow("Y offset:", self.y)
        self.options_form.addRow(QLabel("Tip: use the Preview panel to fine-tune X/Y before running a batch crop."))

    def build_args(self, src, dst):
        geom = f"{self.width.value()}x{self.height.value()}+{self.x.value()}+{self.y.value()}"
        if self.preset.currentText() == "Center crop":
            return ["convert", src, "-gravity", "center", "-crop",
                    f"{self.width.value()}x{self.height.value()}+0+0", "+repage", dst]
        return ["convert", src, "-crop", geom, "+repage", dst]

    def current_settings_dict(self):
        return {"preset": self.preset.currentText(), "w": self.width.value(), "h": self.height.value(),
                "x": self.x.value(), "y": self.y.value()}


# ------------------------------------------------------------- Rotate & Flip
class RotatePage(ToolPageBase):
    title = "Rotate & Orientation"
    default_suffix = "_rotated"

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.mode = QComboBox()
        self.mode.addItems([
            "Auto-orient (apply EXIF, strip tag)", "Rotate 90° CW", "Rotate 90° CCW",
            "Rotate 180°", "Custom angle", "Flip horizontal", "Flip vertical",
        ])
        self.custom_angle = QSpinBox(); self.custom_angle.setRange(-360, 360)
        self.options_form.addRow("Operation:", self.mode)
        self.options_form.addRow("Custom angle:", self.custom_angle)

    def build_args(self, src, dst):
        mode = self.mode.currentText()
        base = ["convert", src]
        if mode.startswith("Auto-orient"):
            return base + ["-auto-orient", dst]
        if mode == "Rotate 90° CW":
            return base + ["-rotate", "90", dst]
        if mode == "Rotate 90° CCW":
            return base + ["-rotate", "-90", dst]
        if mode == "Rotate 180°":
            return base + ["-rotate", "180", dst]
        if mode == "Custom angle":
            return base + ["-background", "none", "-rotate", str(self.custom_angle.value()), dst]
        if mode == "Flip horizontal":
            return base + ["-flop", dst]
        return base + ["-flip", dst]

    def current_settings_dict(self):
        return {"mode": self.mode.currentText(), "angle": self.custom_angle.value()}


# ------------------------------------------------------------------ Compress
class CompressionPage(ToolPageBase):
    title = "Compression"
    default_suffix = ""

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.format_combo = QComboBox(); self.format_combo.addItems(["Keep original", "JPG", "PNG", "WEBP"])
        self.quality = QSlider(Qt.Horizontal); self.quality.setRange(1, 100); self.quality.setValue(85)
        self.quality_label = QLabel("85")
        self.quality.valueChanged.connect(lambda v: self.quality_label.setText(str(v)))
        self.strip_metadata = QCheckBox("Strip metadata"); self.strip_metadata.setChecked(True)
        self.progressive = QCheckBox("Progressive JPEG")
        self.lossless_webp = QCheckBox("Lossless WEBP")
        self.png_level = QSpinBox(); self.png_level.setRange(0, 9); self.png_level.setValue(6)

        qrow = QHBoxLayout(); qrow.addWidget(self.quality); qrow.addWidget(self.quality_label)
        self.options_form.addRow("Output format:", self.format_combo)
        self.options_form.addRow("Quality:", qrow)
        self.options_form.addRow("PNG compression level:", self.png_level)
        self.options_form.addRow(self.strip_metadata)
        self.options_form.addRow(self.progressive)
        self.options_form.addRow(self.lossless_webp)
        info = QLabel("Original / output size and % reduction are shown per file in the results dialog after running.")
        info.setWordWrap(True)
        self.options_form.addRow(info)

    def _target_ext(self, src_ext: str) -> str:
        choice = self.format_combo.currentText()
        return {"JPG": ".jpg", "PNG": ".png", "WEBP": ".webp"}.get(choice, src_ext)

    def start(self) -> None:
        # override to change extension based on chosen format, then reuse base flow
        files = self.batch_widget.file_paths()
        folder = self.output_options.resolved_folder()
        jobs = []
        for idx, src in enumerate(files, start=1):
            base = os.path.basename(src)
            stem, ext = os.path.splitext(base)
            new_ext = self._target_ext(ext)
            template = self.output_options.naming_template.text() or "{name}"
            new_stem = render_name_template(template, idx, base, width=3)
            dst_path = self.output_options.resolve_output_path(folder, new_stem + new_ext)
            orig_size = os.path.getsize(src) if os.path.isfile(src) else 0

            def make_job(s=src, d=dst_path, label=base, orig=orig_size):
                def _job():
                    if d is None:
                        return "skipped"
                    args = self.build_args(s, d)
                    res = self.magick.run(args)
                    if not res.ok:
                        raise RuntimeError(res.stderr.strip() or f"exit code {res.exit_code}")
                    if os.path.isfile(d):
                        new_size = os.path.getsize(d)
                        pct = (1 - new_size / orig) * 100 if orig else 0
                        from core.file_utils import human_size
                        return f"{human_size(orig)} -> {human_size(new_size)} ({pct:.1f}% smaller)"
                    return "ok"
                return label, _job
            jobs.append(make_job())

        def finished(summary):
            ErrorSummaryDialog(summary, self).exec()
            self.history.add(self.title, f"{len(files)} file(s)", folder,
                              self.current_settings_dict(), summary.completed, summary.failed, summary.skipped)

        self.run_controls.run_jobs(jobs, finished)

    def build_args(self, src, dst):
        args = ["convert", src]
        ext = os.path.splitext(dst)[1].lower()
        if self.strip_metadata.isChecked():
            args += ["-strip"]
        if ext in (".jpg", ".jpeg"):
            args += ["-quality", str(self.quality.value())]
            if self.progressive.isChecked():
                args += ["-interlace", "Plane"]
        elif ext == ".png":
            args += ["-define", f"png:compression-level={self.png_level.value()}"]
        elif ext == ".webp":
            args += ["-quality", str(self.quality.value())]
            if self.lossless_webp.isChecked():
                args += ["-define", "webp:lossless=true"]
        args.append(dst)
        return args

    def current_settings_dict(self):
        return {"format": self.format_combo.currentText(), "quality": self.quality.value(),
                "strip_metadata": self.strip_metadata.isChecked()}


# --------------------------------------------------------------------- Adjust
class AdjustmentsPage(ToolPageBase):
    title = "Image Adjustments"
    default_suffix = "_adjusted"

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.brightness = self._slider(-100, 100, 0)
        self.contrast = self._slider(-100, 100, 0)
        self.saturation = self._slider(-100, 300, 0)
        self.gamma = self._slider(10, 300, 100)
        self.sharpen = self._slider(0, 20, 0)
        self.blur = self._slider(0, 20, 0)

        self.options_form.addRow("Brightness:", self.brightness)
        self.options_form.addRow("Contrast:", self.contrast)
        self.options_form.addRow("Saturation:", self.saturation)
        self.options_form.addRow("Gamma (x100):", self.gamma)
        self.options_form.addRow("Sharpen:", self.sharpen)
        self.options_form.addRow("Blur:", self.blur)
        reset = QPushButton("Reset all")
        reset.clicked.connect(self._reset)
        self.options_form.addRow(reset)

    def _slider(self, lo, hi, val):
        s = QSlider(Qt.Horizontal); s.setRange(lo, hi); s.setValue(val)
        return s

    def _reset(self):
        for s, v in [(self.brightness, 0), (self.contrast, 0), (self.saturation, 0),
                     (self.gamma, 100), (self.sharpen, 0), (self.blur, 0)]:
            s.setValue(v)

    def build_args(self, src, dst):
        args = ["convert", src]
        brightness_pct = 100 + self.brightness.value()
        saturation_pct = 100 + self.saturation.value()
        args += ["-brightness-contrast", f"{self.brightness.value()}x{self.contrast.value()}"]
        args += ["-modulate", f"100,{saturation_pct},100"]
        gamma = self.gamma.value() / 100.0
        args += ["-gamma", f"{gamma}"]
        if self.sharpen.value() > 0:
            args += ["-sharpen", f"0x{self.sharpen.value()}"]
        if self.blur.value() > 0:
            args += ["-blur", f"0x{self.blur.value()}"]
        args.append(dst)
        return args

    def current_settings_dict(self):
        return {"brightness": self.brightness.value(), "contrast": self.contrast.value(),
                "saturation": self.saturation.value(), "gamma": self.gamma.value()}


# -------------------------------------------------------------------- Filters
class FiltersPage(ToolPageBase):
    title = "Filters & Effects"
    default_suffix = "_fx"

    EFFECTS = {
        "Sharpen": ["-sharpen", "0x2"],
        "Gaussian blur": ["-gaussian-blur", "0x3"],
        "Edge": ["-edge", "2"],
        "Emboss": ["-emboss", "2"],
        "Charcoal": ["-charcoal", "2"],
        "Sketch": ["-sketch", "0x10+120"],
        "Oil painting": ["-paint", "3"],
        "Vignette": ["-background", "black", "-vignette", "0x30"],
        "Negate": ["-negate"],
        "Grayscale": ["-colorspace", "Gray"],
        "Sepia": ["-sepia-tone", "80%"],
        "Posterize": ["-posterize", "4"],
        "Auto levels": ["-auto-level"],
        "Auto contrast": ["-auto-gamma", "-normalize"],
        "Threshold": ["-threshold", "50%"],
        "Noise reduction": ["-despeckle"],
    }

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.effect_combo = QComboBox()
        self.effect_combo.addItems(list(self.EFFECTS.keys()))
        self.options_form.addRow("Effect:", self.effect_combo)
        note = QLabel("Effects run one at a time on the whole batch. Chain multiple passes by running this "
                       "tool again on the output folder.")
        note.setWordWrap(True)
        self.options_form.addRow(note)

    def build_args(self, src, dst):
        effect_args = self.EFFECTS[self.effect_combo.currentText()]
        return ["convert", src, *effect_args, dst]

    def current_settings_dict(self):
        return {"effect": self.effect_combo.currentText()}
