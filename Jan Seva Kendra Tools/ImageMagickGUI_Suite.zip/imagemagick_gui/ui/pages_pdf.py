"""
ui.pages_pdf
------------
Image -> PDF and PDF -> Image tool pages (spec sections 7, 8, 41).
Delegates the actual orientation-safe page assembly to core.pdf_service.
"""
from __future__ import annotations

import os

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QGroupBox, QFormLayout, QComboBox, QSpinBox,
    QLineEdit, QPushButton, QFileDialog, QLabel, QCheckBox, QMessageBox,
)

from ui.common import OutputOptionsWidget, RunControlsWidget, ErrorSummaryDialog
from core.pdf_service import PdfService, PdfPageOptions, PAGE_SIZES_MM
from core.settings_service import temp_dir
from core.worker import BatchWorker


class PdfCreatePage(QWidget):
    title = "PDF Tools — Images to PDF"

    def __init__(self, batch_widget, magick, settings, history, parent=None):
        super().__init__(parent)
        self.batch_widget = batch_widget
        self.magick = magick
        self.settings = settings
        self.history = history
        self.pdf_service = PdfService(magick)

        root = QVBoxLayout(self)
        root.addWidget(QLabel("<h2>Images → PDF</h2>"))
        box = QGroupBox("Page setup")
        form = QFormLayout(box)

        self.page_size = QComboBox(); self.page_size.addItems(list(PAGE_SIZES_MM.keys()) + ["Custom"])
        self.orientation = QComboBox(); self.orientation.addItems(["AUTO", "PORTRAIT", "LANDSCAPE"])
        self.margin = QComboBox(); self.margin.addItems(["None", "Small", "Medium", "Large", "Custom"])
        self.fit_mode = QComboBox(); self.fit_mode.addItems(["fit", "fill", "stretch", "center"])
        self.dpi = QSpinBox(); self.dpi.setRange(50, 1200); self.dpi.setValue(settings.settings.default_pdf_dpi)
        self.quality = QSpinBox(); self.quality.setRange(1, 100); self.quality.setValue(90)
        self.grayscale = QCheckBox("Grayscale PDF")
        self.background = QComboBox(); self.background.addItems(["white", "black", "transparent"])
        self.output_name = QLineEdit("output.pdf")

        form.addRow("Page size:", self.page_size)
        form.addRow("Orientation:", self.orientation)
        form.addRow("Margins:", self.margin)
        form.addRow("Fit mode:", self.fit_mode)
        form.addRow("DPI:", self.dpi)
        form.addRow("Quality:", self.quality)
        form.addRow("Background:", self.background)
        form.addRow(self.grayscale)
        form.addRow("Output filename:", self.output_name)
        root.addWidget(box)

        warn = QLabel("Images are never stretched unless you explicitly choose the 'stretch' fit mode. "
                       "Portrait photos stay portrait in AUTO mode.")
        warn.setWordWrap(True)
        root.addWidget(warn)

        self.output_options = OutputOptionsWidget(settings)
        root.addWidget(self.output_options)

        self.run_controls = RunControlsWidget()
        self.run_controls.btn_start.setText("Create PDF (Ctrl+Enter)")
        self.run_controls.btn_start.clicked.connect(self.start)
        root.addWidget(self.run_controls)
        root.addStretch()

    def start(self) -> None:
        files = self.batch_widget.file_paths()
        if not files:
            QMessageBox.information(self, "Nothing to do", "Add some images first.")
            return
        folder = self.output_options.resolved_folder()
        out_path = os.path.join(folder, self.output_name.text().strip() or "output.pdf")

        opts = PdfPageOptions(
            page_size=self.page_size.currentText(),
            orientation=self.orientation.currentText(),
            margin=self.margin.currentText(),
            fit_mode=self.fit_mode.currentText(),
            dpi=self.dpi.value(),
            quality=self.quality.value(),
            grayscale=self.grayscale.isChecked(),
            background=self.background.currentText(),
        )

        def job():
            self.pdf_service.images_to_pdf(
                files, out_path, opts,
                tmp_dir=os.path.join(temp_dir(), "pdf_build"),
                progress_cb=lambda i, t, name: self.run_controls._on_progress(i - 1, t, name),
            )
            return "ok"

        jobs = [("Building PDF…", job)]

        def finished(summary):
            ErrorSummaryDialog(summary, self).exec()
            self.history.add(self.title, f"{len(files)} image(s)", out_path,
                              {"page_size": opts.page_size, "orientation": opts.orientation, "fit": opts.fit_mode},
                              summary.completed, summary.failed, summary.skipped)

        self.run_controls.run_jobs(jobs, finished)


class PdfExtractPage(QWidget):
    title = "PDF Tools — PDF to Images"

    def __init__(self, batch_widget, magick, settings, history, parent=None):
        super().__init__(parent)
        self.batch_widget = batch_widget
        self.magick = magick
        self.settings = settings
        self.history = history
        self.pdf_service = PdfService(magick)

        root = QVBoxLayout(self)
        root.addWidget(QLabel("<h2>PDF → Images</h2>"))
        box = QGroupBox("Settings")
        form = QFormLayout(box)

        self.pdf_path = QLineEdit()
        browse = QPushButton("Browse…")
        browse.clicked.connect(self._browse_pdf)
        row = QVBoxLayout(); row.addWidget(self.pdf_path); row.addWidget(browse)
        form.addRow("PDF file:", row)

        self.format = QComboBox(); self.format.addItems(["jpg", "png", "webp", "tiff"])
        self.dpi = QSpinBox(); self.dpi.setRange(50, 1200); self.dpi.setValue(150)
        self.quality = QSpinBox(); self.quality.setRange(1, 100); self.quality.setValue(90)
        self.naming = QLineEdit("document_page_{index}")
        form.addRow("Format:", self.format)
        form.addRow("DPI:", self.dpi)
        form.addRow("Quality:", self.quality)
        form.addRow("Naming template:", self.naming)
        root.addWidget(box)

        self.output_options = OutputOptionsWidget(settings)
        root.addWidget(self.output_options)

        self.run_controls = RunControlsWidget()
        self.run_controls.btn_start.setText("Extract Images (Ctrl+Enter)")
        self.run_controls.btn_start.clicked.connect(self.start)
        root.addWidget(self.run_controls)
        root.addStretch()

    def _browse_pdf(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Select PDF", "", "PDF files (*.pdf)")
        if path:
            self.pdf_path.setText(path)

    def start(self) -> None:
        pdf = self.pdf_path.text().strip()
        if not pdf or not os.path.isfile(pdf):
            QMessageBox.warning(self, "No PDF selected", "Please choose a PDF file first.")
            return
        folder = self.output_options.resolved_folder()

        def job():
            self.pdf_service.pdf_to_images(
                pdf, folder, self.format.currentText(), self.dpi.value(), self.quality.value(),
                self.naming.text() or "page_{index}",
                progress_cb=lambda i, t, name: self.run_controls._on_progress(i - 1, t, name),
            )
            return "ok"

        jobs = [("Extracting pages…", job)]

        def finished(summary):
            ErrorSummaryDialog(summary, self).exec()
            self.history.add(self.title, pdf, folder,
                              {"format": self.format.currentText(), "dpi": self.dpi.value()},
                              summary.completed, summary.failed, summary.skipped)

        self.run_controls.run_jobs(jobs, finished)
