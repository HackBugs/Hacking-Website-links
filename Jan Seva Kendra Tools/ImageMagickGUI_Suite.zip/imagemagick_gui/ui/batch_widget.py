"""
ui.batch_widget
----------------
The shared file queue used by every tool page (spec section 4). Supports
drag-and-drop of files/folders, thumbnails, sorting, natural-order renaming
preview, and remove operations. Thumbnails are generated at a small fixed
size via QImageReader.setScaledSize so full-resolution images are never
loaded into memory just to show a preview (spec section 5/33).
"""
from __future__ import annotations

import os

from PySide6.QtCore import Qt, Signal, QSize
from PySide6.QtGui import QImageReader, QPixmap, QIcon
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem,
    QPushButton, QFileDialog, QAbstractItemView, QLabel, QComboBox, QCheckBox,
    QHeaderView,
)

from core.file_utils import scan_folder, natural_sort_key, human_size, SUPPORTED_EXTENSIONS

THUMB_SIZE = 64
COLUMNS = ["Thumbnail", "Filename", "Format", "Width", "Height", "Size", "Orientation", "Status"]


def make_thumbnail(path: str) -> QPixmap:
    reader = QImageReader(path)
    reader.setAutoTransform(True)
    if not reader.canRead():
        pix = QPixmap(THUMB_SIZE, THUMB_SIZE)
        pix.fill(Qt.lightGray)
        return pix
    size = reader.size()
    if size.isValid():
        size.scale(THUMB_SIZE, THUMB_SIZE, Qt.KeepAspectRatio)
        reader.setScaledSize(size)
    image = reader.read()
    return QPixmap.fromImage(image) if not image.isNull() else QPixmap(THUMB_SIZE, THUMB_SIZE)


class BatchTableWidget(QWidget):
    files_changed = Signal(list)   # emits list[str] whenever the queue changes

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)
        self._paths: list[str] = []

        layout = QVBoxLayout(self)
        toolbar = QHBoxLayout()
        self.btn_add_files = QPushButton("Add Files (Ctrl+O)")
        self.btn_add_folder = QPushButton("Add Folder (Ctrl+Shift+O)")
        self.btn_remove = QPushButton("Remove Selected (Del)")
        self.btn_clear = QPushButton("Remove All")
        self.chk_recursive = QCheckBox("Recursive folder scan")
        self.sort_combo = QComboBox()
        self.sort_combo.addItems(["Filename ↑", "Filename ↓", "Size ↑", "Size ↓", "Width ↑", "Width ↓"])
        for w in (self.btn_add_files, self.btn_add_folder, self.btn_remove, self.btn_clear,
                  self.chk_recursive, self.sort_combo):
            toolbar.addWidget(w)
        toolbar.addStretch()
        layout.addLayout(toolbar)

        self.table = QTableWidget(0, len(COLUMNS))
        self.table.setHorizontalHeaderLabels(COLUMNS)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setIconSize(QSize(THUMB_SIZE, THUMB_SIZE))
        self.table.verticalHeader().setDefaultSectionSize(THUMB_SIZE + 4)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        layout.addWidget(self.table)

        self.status_label = QLabel("0 files")
        layout.addWidget(self.status_label)

        self.btn_add_files.clicked.connect(self.add_files_dialog)
        self.btn_add_folder.clicked.connect(self.add_folder_dialog)
        self.btn_remove.clicked.connect(self.remove_selected)
        self.btn_clear.clicked.connect(self.remove_all)
        self.sort_combo.currentIndexChanged.connect(self._apply_sort)

    # ------------------------------------------------------------- drag/drop
    def dragEnterEvent(self, event):  # noqa: N802 (Qt override)
        if event.mimeData().hasUrls():
            event.acceptProposedAction()

    def dropEvent(self, event):  # noqa: N802 (Qt override)
        paths = [u.toLocalFile() for u in event.mimeData().urls()]
        to_add: list[str] = []
        for p in paths:
            if os.path.isdir(p):
                to_add.extend(scan_folder(p, self.chk_recursive.isChecked()))
            elif os.path.splitext(p)[1].lower() in SUPPORTED_EXTENSIONS:
                to_add.append(p)
        self.add_paths(to_add)

    # ------------------------------------------------------------- add/remove
    def add_files_dialog(self) -> None:
        exts = " ".join(f"*{e}" for e in SUPPORTED_EXTENSIONS)
        files, _ = QFileDialog.getOpenFileNames(self, "Add Images", "", f"Images ({exts})")
        self.add_paths(files)

    def add_folder_dialog(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Add Folder")
        if folder:
            self.add_paths(scan_folder(folder, self.chk_recursive.isChecked()))

    def add_paths(self, paths: list[str]) -> None:
        for p in paths:
            if p not in self._paths and os.path.isfile(p):
                self._paths.append(p)
        self._rebuild_table()

    def remove_selected(self) -> None:
        rows = sorted({idx.row() for idx in self.table.selectedIndexes()}, reverse=True)
        for r in rows:
            del self._paths[r]
        self._rebuild_table()

    def remove_all(self) -> None:
        self._paths.clear()
        self._rebuild_table()

    def file_paths(self) -> list[str]:
        return list(self._paths)

    def set_status(self, row: int, text: str) -> None:
        if 0 <= row < self.table.rowCount():
            item = self.table.item(row, COLUMNS.index("Status"))
            if item:
                item.setText(text)

    # ------------------------------------------------------------- internal
    def _apply_sort(self) -> None:
        choice = self.sort_combo.currentText()
        if choice.startswith("Filename"):
            self._paths.sort(key=lambda p: natural_sort_key(os.path.basename(p)), reverse="↓" in choice)
        elif choice.startswith("Size"):
            self._paths.sort(key=lambda p: os.path.getsize(p) if os.path.isfile(p) else 0, reverse="↓" in choice)
        elif choice.startswith("Width"):
            from PySide6.QtGui import QImageReader as _R
            self._paths.sort(key=lambda p: _R(p).size().width(), reverse="↓" in choice)
        self._rebuild_table()

    def _rebuild_table(self) -> None:
        self.table.setRowCount(0)
        for path in self._paths:
            row = self.table.rowCount()
            self.table.insertRow(row)

            thumb_item = QTableWidgetItem()
            if os.path.splitext(path)[1].lower() != ".pdf":
                thumb_item.setIcon(QIcon(make_thumbnail(path)))
            self.table.setItem(row, 0, thumb_item)

            self.table.setItem(row, 1, QTableWidgetItem(os.path.basename(path)))
            ext = os.path.splitext(path)[1].lstrip(".").upper()
            self.table.setItem(row, 2, QTableWidgetItem(ext))

            reader = QImageReader(path)
            size = reader.size()
            self.table.setItem(row, 3, QTableWidgetItem(str(size.width()) if size.isValid() else "-"))
            self.table.setItem(row, 4, QTableWidgetItem(str(size.height()) if size.isValid() else "-"))

            try:
                sz = human_size(os.path.getsize(path))
            except OSError:
                sz = "-"
            self.table.setItem(row, 5, QTableWidgetItem(sz))

            orientation = "-"
            if size.isValid():
                orientation = "Portrait" if size.height() >= size.width() else "Landscape"
            self.table.setItem(row, 6, QTableWidgetItem(orientation))
            self.table.setItem(row, 7, QTableWidgetItem("Ready"))

        self.status_label.setText(f"{len(self._paths)} files")
        self.files_changed.emit(self._paths)
