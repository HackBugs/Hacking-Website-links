"""
ui.main_window
---------------
Sidebar navigation + stacked workspace (spec section 2). Owns the single
shared file queue used by every tool page, the ImageMagick backend, and the
settings/history/preset services, then wires everything together.
"""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QKeySequence, QShortcut
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QHBoxLayout, QListWidget, QListWidgetItem,
    QStackedWidget, QStatusBar, QLabel, QTabWidget, QMessageBox, QToolBar,
)

from core.imagemagick_service import ImageMagickService
from core.settings_service import SettingsService
from core.history_service import HistoryService
from core.preset_service import PresetService

from ui.batch_widget import BatchTableWidget
from ui.pages_extra import HomePage, WatermarkPage, AdvancedPage, HistoryPage, SettingsPage
from ui.pages_transform import ResizePage, CropPage, RotatePage, CompressionPage, AdjustmentsPage, FiltersPage
from ui.pages_pdf import PdfCreatePage, PdfExtractPage

DARK_QSS = """
QWidget { background-color: #1e1f22; color: #e6e6e6; }
QGroupBox { border: 1px solid #3a3b3f; border-radius: 6px; margin-top: 10px; padding-top: 8px; }
QGroupBox::title { subcontrol-origin: margin; left: 8px; }
QPushButton { background-color: #2d2f33; border: 1px solid #46484d; border-radius: 4px; padding: 6px 10px; }
QPushButton:hover { background-color: #3a3c41; }
QLineEdit, QComboBox, QSpinBox, QPlainTextEdit, QTableWidget { background-color: #26272b; border: 1px solid #46484d; border-radius: 4px; }
QListWidget#nav { background-color: #17181a; border: none; font-size: 13px; }
QListWidget#nav::item { padding: 10px 14px; }
QListWidget#nav::item:selected { background-color: #2f6fed; color: white; }
"""

LIGHT_QSS = """
QListWidget#nav { background-color: #f4f5f7; border: none; font-size: 13px; }
QListWidget#nav::item { padding: 10px 14px; }
QListWidget#nav::item:selected { background-color: #2f6fed; color: white; }
QGroupBox { border: 1px solid #d8dadf; border-radius: 6px; margin-top: 10px; padding-top: 8px; }
QGroupBox::title { subcontrol-origin: margin; left: 8px; }
"""


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ImageMagick GUI Suite")
        self.resize(1280, 820)

        self.magick = ImageMagickService()
        self.settings = SettingsService()
        self.history = HistoryService()
        self.presets = PresetService()

        if self.settings.settings.magick_path:
            self.magick.set_path(self.settings.settings.magick_path)
        if not self.magick.is_ready:
            info = self.magick.autodetect()
            if info.ok:
                self.settings.update(magick_path=info.path)

        self.batch_widget = BatchTableWidget()

        central = QWidget()
        layout = QHBoxLayout(central)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self.nav = QListWidget()
        self.nav.setObjectName("nav")
        self.nav.setFixedWidth(210)
        layout.addWidget(self.nav)

        self.stack = QStackedWidget()
        layout.addWidget(self.stack, 1)
        self.setCentralWidget(central)

        self._build_pages()
        self.nav.currentRowChanged.connect(self.stack.setCurrentIndex)
        self.nav.setCurrentRow(0)

        self.status = QStatusBar()
        self.magick_status_label = QLabel()
        self.status.addPermanentWidget(self.magick_status_label)
        self.setStatusBar(self.status)
        self._refresh_status()

        self._build_toolbar()
        self._build_shortcuts()
        self._apply_theme()

        if not self.settings.settings.first_run_complete:
            self._show_first_run_hint()

    # --------------------------------------------------------------- pages
    def _build_pages(self) -> None:
        def add(name: str, widget: QWidget) -> None:
            self.nav.addItem(QListWidgetItem(name))
            self.stack.addWidget(widget)

        args = (self.batch_widget, self.magick, self.settings, self.history)

        add("Home", HomePage(self.magick, self.settings, self.navigate_to))
        add("Batch Converter", self._build_batch_page())

        pdf_tabs = QTabWidget()
        pdf_tabs.addTab(PdfCreatePage(*args), "Images → PDF")
        pdf_tabs.addTab(PdfExtractPage(*args), "PDF → Images")
        add("PDF Tools", pdf_tabs)

        add("Resize", ResizePage(*args))
        add("Crop", CropPage(*args))
        add("Rotate & Orientation", RotatePage(*args))
        add("Compression", CompressionPage(*args))
        add("Image Adjustments", AdjustmentsPage(*args))
        add("Watermark & Text", WatermarkPage(*args))
        add("Filters & Effects", FiltersPage(*args))
        add("Advanced ImageMagick", AdvancedPage(*args))
        add("History", HistoryPage(self.history))
        add("Settings", SettingsPage(self.magick, self.settings))

    def _build_batch_page(self) -> QWidget:
        from PySide6.QtWidgets import QVBoxLayout, QLabel
        page = QWidget()
        v = QVBoxLayout(page)
        v.addWidget(QLabel("<h2>Batch Converter</h2>"))
        v.addWidget(QLabel("Add your files or folders here, then switch to any tool tab (Resize, PDF Tools, "
                            "Compression, …) on the left — they all operate on this shared queue."))
        v.addWidget(self.batch_widget)
        return page

    def navigate_to(self, name: str) -> None:
        for i in range(self.nav.count()):
            if self.nav.item(i).text() == name:
                self.nav.setCurrentRow(i)
                return

    # ----------------------------------------------------------------- misc
    def _refresh_status(self) -> None:
        if self.magick.is_ready:
            self.magick_status_label.setText(f"ImageMagick: ready ({self.magick.path})")
        else:
            self.magick_status_label.setText("ImageMagick: not configured — see Home or Settings")

    def _build_toolbar(self) -> None:
        bar = QToolBar("Main")
        bar.setMovable(False)
        self.addToolBar(bar)
        add_files = bar.addAction("Add Files")
        add_files.triggered.connect(self.batch_widget.add_files_dialog)
        add_folder = bar.addAction("Add Folder")
        add_folder.triggered.connect(self.batch_widget.add_folder_dialog)
        bar.addAction("Batch Converter").triggered.connect(lambda: self.navigate_to("Batch Converter"))

    def _build_shortcuts(self) -> None:
        QShortcut(QKeySequence("Ctrl+O"), self, activated=self.batch_widget.add_files_dialog)
        QShortcut(QKeySequence("Ctrl+Shift+O"), self, activated=self.batch_widget.add_folder_dialog)
        QShortcut(QKeySequence("Ctrl+A"), self, activated=self.batch_widget.table.selectAll)
        QShortcut(QKeySequence("Delete"), self, activated=self.batch_widget.remove_selected)
        QShortcut(QKeySequence("Ctrl+Return"), self, activated=self._start_current_page)
        QShortcut(QKeySequence("Escape"), self, activated=self._cancel_current_page)

    def _start_current_page(self) -> None:
        page = self.stack.currentWidget()
        target = page.currentWidget() if isinstance(page, QTabWidget) else page
        if hasattr(target, "start"):
            target.start()

    def _cancel_current_page(self) -> None:
        page = self.stack.currentWidget()
        target = page.currentWidget() if isinstance(page, QTabWidget) else page
        rc = getattr(target, "run_controls", None)
        if rc:
            rc._cancel()

    def _apply_theme(self) -> None:
        theme = self.settings.settings.theme
        if theme == "Dark":
            self.setStyleSheet(DARK_QSS)
        elif theme == "Light":
            self.setStyleSheet(LIGHT_QSS)
        else:
            self.setStyleSheet(LIGHT_QSS)  # "System": default to light QSS, native palette otherwise

    def _show_first_run_hint(self) -> None:
        if self.magick.is_ready:
            QMessageBox.information(
                self, "Welcome",
                f"ImageMagick {self.magick.autodetect().version or ''} was detected automatically.\n\n"
                "Add some files on the Batch Converter tab, then pick a tool from the sidebar to get started.",
            )
        else:
            QMessageBox.warning(
                self, "ImageMagick not found",
                "This application needs ImageMagick installed.\n\n"
                "Download it from https://imagemagick.org/script/download.php, then use "
                "Home → 'Select executable manually…' (or Settings) to point the app at magick.exe.",
            )
        self.settings.update(first_run_complete=True)
