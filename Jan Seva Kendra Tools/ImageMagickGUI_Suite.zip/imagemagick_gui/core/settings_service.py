"""
core.settings_service
----------------------
Persists application settings (spec section 30) as JSON under the OS-standard
config directory. Uses Qt's QStandardPaths so it works correctly on Windows
(%APPDATA%\\ImageMagickGUI), macOS, and Linux without hardcoding paths.
"""
from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass, field
from typing import Optional

from PySide6.QtCore import QStandardPaths


def config_dir() -> str:
    base = QStandardPaths.writableLocation(QStandardPaths.AppConfigLocation)
    if not base:
        base = os.path.join(os.path.expanduser("~"), ".imagemagick_gui")
    os.makedirs(base, exist_ok=True)
    return base


def logs_dir() -> str:
    d = os.path.join(config_dir(), "logs")
    os.makedirs(d, exist_ok=True)
    return d


def temp_dir() -> str:
    d = os.path.join(config_dir(), "temp")
    os.makedirs(d, exist_ok=True)
    return d


@dataclass
class AppSettings:
    magick_path: Optional[str] = None
    default_output_folder: str = field(default_factory=lambda: os.path.join(os.path.expanduser("~"), "ImageMagickGUI_Output"))
    default_pdf_dpi: int = 150
    default_jpeg_quality: int = 85
    default_pdf_page_size: str = "A4"
    default_pdf_orientation: str = "AUTO"
    theme: str = "System"
    max_parallel_workers: int = 2
    temp_folder: str = field(default_factory=temp_dir)
    logging_level: str = "INFO"
    overwrite_policy: str = "Ask"          # Ask | Overwrite | Skip | Rename
    recursive_folder_scan: bool = False
    first_run_complete: bool = False

    def to_json(self) -> str:
        return json.dumps(asdict(self), indent=2)

    @staticmethod
    def from_json(text: str) -> "AppSettings":
        data = json.loads(text)
        return AppSettings(**{k: v for k, v in data.items() if k in AppSettings.__dataclass_fields__})


class SettingsService:
    FILE_NAME = "settings.json"

    def __init__(self):
        self._file = os.path.join(config_dir(), self.FILE_NAME)
        self.settings = self._load()

    def _load(self) -> AppSettings:
        if os.path.isfile(self._file):
            try:
                with open(self._file, "r", encoding="utf-8") as fh:
                    return AppSettings.from_json(fh.read())
            except Exception:  # noqa: BLE001
                pass
        return AppSettings()

    def save(self) -> None:
        with open(self._file, "w", encoding="utf-8") as fh:
            fh.write(self.settings.to_json())

    def update(self, **kwargs) -> None:
        for k, v in kwargs.items():
            if hasattr(self.settings, k):
                setattr(self.settings, k, v)
        self.save()
