"""
core.preset_service
--------------------
Create / edit / duplicate / delete / import / export presets (spec section 22).
A preset is just a named dict of operation settings, stored as one JSON file
per preset inside the user config directory so users can share individual
preset files easily.
"""
from __future__ import annotations

import json
import os
import shutil
from typing import Any

from core.settings_service import config_dir


BUILT_IN_PRESETS: dict[str, dict[str, Any]] = {
    "A4 Portrait PDF": {"type": "pdf", "page_size": "A4", "orientation": "PORTRAIT", "fit": "fit", "dpi": 150},
    "A4 Landscape PDF": {"type": "pdf", "page_size": "A4", "orientation": "LANDSCAPE", "fit": "fit", "dpi": 150},
    "Compress JPG 70%": {"type": "compression", "format": "jpg", "quality": 70, "strip_metadata": True},
    "Web Images 1200px": {"type": "resize", "mode": "max", "width": 1200, "height": 1200, "filter": "Lanczos"},
    "Scan to PDF": {"type": "scan", "grayscale": False, "page_size": "A4", "dpi": 200},
    "Grayscale Scan PDF": {"type": "scan", "grayscale": True, "page_size": "A4", "dpi": 200},
    "Passport Photo": {"type": "resize", "mode": "exact", "width": 413, "height": 531, "preserve_aspect": False},
    "WhatsApp Image Compression": {"type": "compression", "format": "jpg", "quality": 60, "strip_metadata": True},
}


class PresetService:
    def __init__(self):
        self.dir = os.path.join(config_dir(), "presets")
        os.makedirs(self.dir, exist_ok=True)
        self._ensure_built_ins()

    def _ensure_built_ins(self) -> None:
        if os.listdir(self.dir):
            return
        for name, data in BUILT_IN_PRESETS.items():
            self.save(name, data)

    def _path_for(self, name: str) -> str:
        safe = "".join(c for c in name if c.isalnum() or c in " _-").strip() or "preset"
        return os.path.join(self.dir, f"{safe}.json")

    def list(self) -> list[str]:
        return sorted(f[:-5] for f in os.listdir(self.dir) if f.endswith(".json"))

    def load(self, name: str) -> dict[str, Any]:
        with open(self._path_for(name), "r", encoding="utf-8") as fh:
            return json.load(fh)

    def save(self, name: str, data: dict[str, Any]) -> None:
        with open(self._path_for(name), "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2)

    def duplicate(self, name: str, new_name: str) -> None:
        self.save(new_name, self.load(name))

    def delete(self, name: str) -> None:
        p = self._path_for(name)
        if os.path.isfile(p):
            os.remove(p)

    def export(self, name: str, dest_path: str) -> None:
        shutil.copy(self._path_for(name), dest_path)

    def import_file(self, src_path: str) -> str:
        name = os.path.splitext(os.path.basename(src_path))[0]
        with open(src_path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        self.save(name, data)
        return name
