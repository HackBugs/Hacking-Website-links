"""
core.file_utils
----------------
Natural sorting, output filename templating, and recursive folder scanning
(spec sections 4 and 28).
"""
from __future__ import annotations

import os
import re
from datetime import datetime

SUPPORTED_EXTENSIONS = {
    ".jpg", ".jpeg", ".png", ".webp", ".tif", ".tiff",
    ".bmp", ".gif", ".ico", ".heic", ".heif", ".pdf",
}


def natural_sort_key(text: str):
    """1,2,3,...,10,11 instead of 1,10,11,2,3 (spec section 28)."""
    return [int(chunk) if chunk.isdigit() else chunk.lower()
            for chunk in re.split(r"(\d+)", text)]


def human_size(num_bytes: int) -> str:
    size = float(num_bytes)
    for unit in ["B", "KB", "MB", "GB"]:
        if size < 1024 or unit == "GB":
            return f"{size:.1f} {unit}" if unit != "B" else f"{int(size)} {unit}"
        size /= 1024
    return f"{size:.1f} GB"


def scan_folder(folder: str, recursive: bool = False) -> list[str]:
    results: list[str] = []
    if recursive:
        for root, _dirs, files in os.walk(folder):
            for f in files:
                if os.path.splitext(f)[1].lower() in SUPPORTED_EXTENSIONS:
                    results.append(os.path.join(root, f))
    else:
        for f in os.listdir(folder):
            full = os.path.join(folder, f)
            if os.path.isfile(full) and os.path.splitext(f)[1].lower() in SUPPORTED_EXTENSIONS:
                results.append(full)
    results.sort(key=natural_sort_key)
    return results


def render_name_template(template: str, index: int, original_name: str, width: int = 3) -> str:
    """
    Supports {index}, {name}, {date} tokens, e.g.:
      {index}_{name}   ->  001_photo
      page_{index}     ->  page_001
    `index` is 1-based; zero-padded to `width` digits.
    """
    stem, _ext = os.path.splitext(original_name)
    return (
        template
        .replace("{index}", str(index).zfill(width))
        .replace("{name}", stem)
        .replace("{date}", datetime.now().strftime("%Y%m%d"))
    )


def unique_output_path(path: str, policy: str = "Rename") -> str | None:
    """
    Apply the overwrite policy (spec section 27):
      Overwrite -> return path unchanged
      Skip      -> return None (caller should skip this file)
      Rename    -> append (1), (2), ... until free
      Ask       -> caller handles the prompt before calling this; treat as Rename here.
    """
    if not os.path.exists(path):
        return path
    if policy == "Overwrite":
        return path
    if policy == "Skip":
        return None

    stem, ext = os.path.splitext(path)
    n = 1
    while True:
        candidate = f"{stem} ({n}){ext}"
        if not os.path.exists(candidate):
            return candidate
        n += 1
