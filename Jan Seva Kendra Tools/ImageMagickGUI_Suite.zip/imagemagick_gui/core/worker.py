"""
core.worker
-----------
Runs a list of per-file jobs on a background QThread so the UI never
freezes (spec section 25). Supports cooperative cancellation and reports
progress, current file/operation, and a final Completed/Failed/Skipped
summary (spec section 26).
"""
from __future__ import annotations

import time
import traceback
from dataclasses import dataclass, field
from typing import Callable

from PySide6.QtCore import QThread, Signal


@dataclass
class JobResult:
    file_name: str
    status: str          # "Completed" | "Failed" | "Skipped"
    message: str = ""
    duration: float = 0.0


@dataclass
class BatchSummary:
    completed: int = 0
    failed: int = 0
    skipped: int = 0
    results: list[JobResult] = field(default_factory=list)


class BatchWorker(QThread):
    """
    `jobs` is a list of (label, callable) pairs. Each callable receives no
    arguments, does the actual ImageMagick work, and must raise on failure
    or return "skipped" (str) to mark itself skipped.
    """
    progress = Signal(int, int, str)       # completed_count, total, current_label
    finished_summary = Signal(object)      # BatchSummary

    def __init__(self, jobs: list[tuple[str, Callable[[], object]]]):
        super().__init__()
        self._jobs = jobs
        self._cancelled = False

    def cancel(self) -> None:
        self._cancelled = True

    def run(self) -> None:  # noqa: D102 (QThread override)
        summary = BatchSummary()
        total = len(self._jobs)
        for i, (label, fn) in enumerate(self._jobs, start=1):
            if self._cancelled:
                summary.skipped += total - i + 1
                for label2, _ in self._jobs[i - 1:]:
                    summary.results.append(JobResult(label2, "Skipped", "Cancelled by user"))
                break

            self.progress.emit(i - 1, total, label)
            start = time.time()
            try:
                outcome = fn()
                duration = time.time() - start
                if outcome == "skipped":
                    summary.skipped += 1
                    summary.results.append(JobResult(label, "Skipped", "Output already exists", duration))
                else:
                    # `outcome` may be a plain "ok"/None, or a human-readable info
                    # string (e.g. compression size reduction) to show in the summary.
                    info = outcome if isinstance(outcome, str) and outcome != "ok" else ""
                    summary.completed += 1
                    summary.results.append(JobResult(label, "Completed", info, duration))
            except Exception as exc:  # noqa: BLE001
                duration = time.time() - start
                summary.failed += 1
                summary.results.append(JobResult(label, "Failed", f"{exc}\n{traceback.format_exc(limit=2)}", duration))
            self.progress.emit(i, total, label)

        self.finished_summary.emit(summary)
