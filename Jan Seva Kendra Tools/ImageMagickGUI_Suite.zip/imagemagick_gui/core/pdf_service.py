"""
core.pdf_service
-----------------
Image -> PDF and PDF -> Image conversion, implementing the careful
orientation logic from spec sections 6, 7, 8 and 41:

    1. Read image metadata.
    2. Apply EXIF orientation physically (-auto-orient).
    3. Normalize orientation metadata (auto-orient also strips the tag).
    4. Determine resulting width/height.
    5. Determine portrait vs landscape from the *normalized* pixels.
    6. Build the PDF page according to the selected mode (AUTO/PORTRAIT/LANDSCAPE).
    7. Fit the image preserving aspect ratio unless the user explicitly
       chose Stretch.
    8. A portrait photo therefore never silently becomes landscape.
"""
from __future__ import annotations

import os
import shutil
from dataclasses import dataclass
from typing import Callable, Optional

from core.imagemagick_service import ImageMagickService

# Page sizes in millimeters (width, height) - PORTRAIT reference.
PAGE_SIZES_MM = {
    "A4": (210, 297),
    "A3": (297, 420),
    "A5": (148, 210),
    "Letter": (215.9, 279.4),
    "Legal": (215.9, 355.6),
}

MARGIN_MM = {"None": 0, "Small": 5, "Medium": 12, "Large": 25}


def mm_to_px(mm: float, dpi: int) -> int:
    return round(mm / 25.4 * dpi)


@dataclass
class PdfPageOptions:
    page_size: str = "A4"          # one of PAGE_SIZES_MM or "Custom"
    custom_mm: Optional[tuple[float, float]] = None
    orientation: str = "AUTO"      # AUTO | PORTRAIT | LANDSCAPE
    margin: str = "None"           # None | Small | Medium | Large | Custom
    custom_margin_mm: float = 0
    fit_mode: str = "fit"          # fit | fill | stretch | center
    dpi: int = 150
    quality: int = 90
    grayscale: bool = False
    background: str = "white"


class PdfService:
    def __init__(self, magick: ImageMagickService):
        self.magick = magick

    # ------------------------------------------------------------- helpers
    def _page_size_px(self, opts: PdfPageOptions, image_is_portrait: bool) -> tuple[int, int]:
        mm = opts.custom_mm if opts.page_size == "Custom" and opts.custom_mm else PAGE_SIZES_MM.get(opts.page_size, PAGE_SIZES_MM["A4"])
        w_mm, h_mm = mm  # portrait reference (narrow, tall)

        if opts.orientation == "AUTO":
            want_portrait = image_is_portrait
        elif opts.orientation == "PORTRAIT":
            want_portrait = True
        else:  # LANDSCAPE
            want_portrait = False

        if not want_portrait:
            w_mm, h_mm = h_mm, w_mm

        margin_mm = opts.custom_margin_mm if opts.margin == "Custom" else MARGIN_MM.get(opts.margin, 0)
        page_w = mm_to_px(w_mm, opts.dpi)
        page_h = mm_to_px(h_mm, opts.dpi)
        margin_px = mm_to_px(margin_mm, opts.dpi)
        return max(page_w - 2 * margin_px, 1), max(page_h - 2 * margin_px, 1)

    def _normalize_and_measure(self, src: str, tmp_dir: str, index: int) -> tuple[str, int, int]:
        """Auto-orient the image into a temp PNG and return (path, width, height)."""
        normalized = os.path.join(tmp_dir, f"_norm_{index:04d}.png")
        res = self.magick.run(["convert", src, "-auto-orient", normalized])
        if not res.ok:
            raise RuntimeError(f"Failed to normalize orientation for {src}: {res.stderr.strip()}")
        ident = self.magick.identify(normalized)
        if not ident.ok:
            raise RuntimeError(f"Failed to read dimensions for {src}: {ident.stderr.strip()}")
        w_str, h_str = ident.stdout.split("|")[0], ident.stdout.split("|")[1]
        return normalized, int(w_str), int(h_str)

    def _compose_page(self, normalized_src: str, page_w: int, page_h: int, opts: PdfPageOptions,
                       tmp_dir: str, index: int) -> str:
        out = os.path.join(tmp_dir, f"_page_{index:04d}.png")
        bg = "none" if opts.background == "transparent" else opts.background

        if opts.fit_mode == "stretch":
            resize_arg = f"{page_w}x{page_h}!"          # '!' = ignore aspect ratio, only here
            args = ["convert", normalized_src, "-resize", resize_arg,
                    "-background", bg, "-gravity", "center", "-extent", f"{page_w}x{page_h}", out]
        elif opts.fit_mode == "fill":
            args = ["convert", normalized_src, "-resize", f"{page_w}x{page_h}^",
                    "-gravity", "center", "-extent", f"{page_w}x{page_h}", out]
        elif opts.fit_mode == "center":
            args = ["convert", normalized_src, "-background", bg,
                    "-gravity", "center", "-extent", f"{page_w}x{page_h}", out]
        else:  # "fit" (default) - preserve aspect ratio, no crop, no stretch
            args = ["convert", normalized_src, "-resize", f"{page_w}x{page_h}",
                    "-background", bg, "-gravity", "center", "-extent", f"{page_w}x{page_h}", out]

        if opts.grayscale:
            args = args[:-1] + ["-colorspace", "Gray"] + [out]
        res = self.magick.run(args)
        if not res.ok:
            raise RuntimeError(f"Failed to compose page for {normalized_src}: {res.stderr.strip()}")
        return out

    # --------------------------------------------------------------- public
    def images_to_pdf(
        self,
        image_paths: list[str],
        output_path: str,
        opts: PdfPageOptions,
        tmp_dir: str,
        progress_cb: Optional[Callable[[int, int, str], None]] = None,
    ) -> None:
        """Build a single multi-page PDF from `image_paths`, in the given order."""
        os.makedirs(tmp_dir, exist_ok=True)
        page_files: list[str] = []
        try:
            total = len(image_paths)
            for i, src in enumerate(image_paths, start=1):
                if progress_cb:
                    progress_cb(i, total, os.path.basename(src))
                normalized, w, h = self._normalize_and_measure(src, tmp_dir, i)
                is_portrait = h >= w
                page_w, page_h = self._page_size_px(opts, is_portrait)
                page_file = self._compose_page(normalized, page_w, page_h, opts, tmp_dir, i)
                page_files.append(page_file)

            args = ["convert", *page_files, "-density", str(opts.dpi), "-quality", str(opts.quality)]
            if opts.grayscale:
                args += ["-colorspace", "Gray"]
            args.append(output_path)
            res = self.magick.run(args, timeout=600)
            if not res.ok:
                raise RuntimeError(f"Failed to assemble PDF: {res.stderr.strip()}")
        finally:
            shutil.rmtree(tmp_dir, ignore_errors=True)

    def pdf_to_images(
        self,
        pdf_path: str,
        output_dir: str,
        fmt: str,
        dpi: int,
        quality: int,
        naming_template: str,
        page_range: Optional[tuple[int, int]] = None,
        progress_cb: Optional[Callable[[int, int, str], None]] = None,
    ) -> list[str]:
        os.makedirs(output_dir, exist_ok=True)
        # Find page count first if no explicit range given.
        if page_range is None:
            ident = self.magick.run(["identify", pdf_path])
            page_count = len(ident.stdout.strip().splitlines()) if ident.ok else 1
            start, end = 0, page_count - 1
        else:
            start, end = page_range

        outputs: list[str] = []
        total = end - start + 1
        for offset, page_no in enumerate(range(start, end + 1), start=1):
            if progress_cb:
                progress_cb(offset, total, f"page {page_no + 1}")
            from core.file_utils import render_name_template
            name = render_name_template(naming_template, page_no + 1, f"page.{fmt}")
            out_path = os.path.join(output_dir, f"{name}.{fmt}")
            args = ["convert", "-density", str(dpi), f"{pdf_path}[{page_no}]"]
            if fmt.lower() in ("jpg", "jpeg", "webp"):
                args += ["-quality", str(quality)]
            args.append(out_path)
            res = self.magick.run(args, timeout=300)
            if not res.ok:
                raise RuntimeError(f"Failed to render page {page_no + 1}: {res.stderr.strip()}")
            outputs.append(out_path)
        return outputs
