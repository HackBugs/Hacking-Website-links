"""
core.imagemagick_service
-------------------------
Detects the ImageMagick backend (system-installed or manually selected),
reports its version, and executes commands safely.

Security notes (see spec section 32/37):
 - We NEVER build a shell string and pass shell=True.
 - All arguments are passed as a Python list to subprocess, so spaces,
   unicode, and special characters in filenames are handled safely and
   command injection is not possible.
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
from dataclasses import dataclass
from typing import Optional


# Windows default install locations we probe if the exe is not on PATH.
COMMON_WINDOWS_PATHS = [
    r"C:\Program Files\ImageMagick-7.1.1-Q16-HDRI\magick.exe",
    r"C:\Program Files\ImageMagick-7.1.1-Q16\magick.exe",
    r"C:\Program Files\ImageMagick-7.1.0-Q16-HDRI\magick.exe",
    r"C:\Program Files\ImageMagick-7.1.0-Q16\magick.exe",
    r"C:\Program Files (x86)\ImageMagick-7.1.1-Q16\magick.exe",
]


@dataclass
class ImageMagickInfo:
    path: Optional[str]
    version: Optional[str]
    ok: bool
    error: Optional[str] = None


@dataclass
class RunResult:
    ok: bool
    exit_code: int
    stdout: str
    stderr: str
    command: list[str]


class ImageMagickService:
    """Wraps the `magick` executable. One instance is shared app-wide."""

    def __init__(self, executable_path: Optional[str] = None):
        self._path = executable_path

    # ---------------------------------------------------------- detection
    def autodetect(self) -> ImageMagickInfo:
        """Try PATH first, then common Windows install locations."""
        candidate = shutil.which("magick") or shutil.which("magick.exe")
        if not candidate:
            for p in COMMON_WINDOWS_PATHS:
                if os.path.isfile(p):
                    candidate = p
                    break
        if not candidate:
            return ImageMagickInfo(None, None, False, "ImageMagick not found on PATH or common install locations.")
        return self.set_path(candidate)

    def set_path(self, path: str) -> ImageMagickInfo:
        """Validate a manually-chosen executable and store it if valid."""
        if not path or not os.path.isfile(path):
            return ImageMagickInfo(path, None, False, "File does not exist.")
        try:
            proc = subprocess.run(
                [path, "-version"],
                capture_output=True,
                text=True,
                timeout=10,
            )
        except Exception as exc:  # noqa: BLE001
            return ImageMagickInfo(path, None, False, f"Failed to execute: {exc}")

        if proc.returncode != 0:
            return ImageMagickInfo(path, None, False, "Executable did not respond correctly to -version.")

        version_match = re.search(r"ImageMagick\s+([\d.\-]+)", proc.stdout)
        version = version_match.group(1) if version_match else proc.stdout.splitlines()[0]
        self._path = path
        return ImageMagickInfo(path, version, True)

    @property
    def path(self) -> Optional[str]:
        return self._path

    @property
    def is_ready(self) -> bool:
        return bool(self._path and os.path.isfile(self._path))

    def supports_delegate(self, name: str) -> bool:
        """Check the compiled 'magick -list delegate' / '-list format' output for a keyword (e.g. 'heic', 'pdf')."""
        if not self.is_ready:
            return False
        try:
            proc = subprocess.run([self._path, "-list", "format"], capture_output=True, text=True, timeout=10)
            return name.lower() in proc.stdout.lower()
        except Exception:  # noqa: BLE001
            return False

    # ---------------------------------------------------------- execution
    def run(self, args: list[str], timeout: Optional[int] = 120, cwd: Optional[str] = None) -> RunResult:
        """
        Execute `magick <args>` safely as an argument list.
        `args` must NOT contain the executable name itself.
        """
        if not self.is_ready:
            return RunResult(False, -1, "", "ImageMagick executable is not configured.", args)

        full_cmd = [self._path, *args]
        try:
            proc = subprocess.run(
                full_cmd,
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=cwd,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
            )
            return RunResult(proc.returncode == 0, proc.returncode, proc.stdout, proc.stderr, full_cmd)
        except subprocess.TimeoutExpired as exc:
            return RunResult(False, -1, "", f"Timed out after {timeout}s: {exc}", full_cmd)
        except Exception as exc:  # noqa: BLE001
            return RunResult(False, -1, "", str(exc), full_cmd)

    def identify(self, image_path: str) -> RunResult:
        """Return width/height/format/etc using a stable machine-readable format string."""
        fmt = "%w|%h|%m|%[colorspace]|%x|%y|%[EXIF:Orientation]|%b"
        return self.run(["identify", "-format", fmt, image_path])


def sanitize_custom_args(raw: str) -> tuple[list[str], list[str]]:
    """
    Split a user-supplied "advanced custom arguments" string into a safe list.
    Returns (args, warnings). We do not allow shell metacharacters or attempts
    to chain commands; we only allow a plain, space-separated argument list,
    which is then passed as a list (never through a shell).
    """
    warnings: list[str] = []
    forbidden = ["&&", "||", ";", "|", "`", "$(", ">", "<", "\n"]
    for token in forbidden:
        if token in raw:
            warnings.append(f"Removed disallowed sequence: {token!r}")
            raw = raw.replace(token, " ")
    try:
        import shlex

        args = shlex.split(raw)
    except ValueError as exc:
        warnings.append(f"Could not parse arguments safely: {exc}")
        args = []
    return args, warnings
