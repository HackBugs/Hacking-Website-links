"""
core.history_service
---------------------
Stores recent operations (spec section 29) as JSON lines so old history
does not require rewriting the whole file. Does not store image bytes,
only paths and settings.
"""
from __future__ import annotations

import json
import os
import time
from dataclasses import asdict, dataclass
from typing import Any, Optional

from core.settings_service import config_dir


@dataclass
class HistoryEntry:
    timestamp: float
    operation: str
    input_summary: str
    output_summary: str
    settings: dict[str, Any]
    completed: int
    failed: int
    skipped: int


class HistoryService:
    FILE_NAME = "history.jsonl"
    MAX_ENTRIES = 500

    def __init__(self):
        self._file = os.path.join(config_dir(), self.FILE_NAME)

    def add(self, operation: str, input_summary: str, output_summary: str,
             settings: dict[str, Any], completed: int, failed: int, skipped: int) -> None:
        entry = HistoryEntry(time.time(), operation, input_summary, output_summary,
                              settings, completed, failed, skipped)
        with open(self._file, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(asdict(entry)) + "\n")
        self._trim()

    def _trim(self) -> None:
        if not os.path.isfile(self._file):
            return
        with open(self._file, "r", encoding="utf-8") as fh:
            lines = fh.readlines()
        if len(lines) > self.MAX_ENTRIES:
            with open(self._file, "w", encoding="utf-8") as fh:
                fh.writelines(lines[-self.MAX_ENTRIES:])

    def list(self) -> list[HistoryEntry]:
        if not os.path.isfile(self._file):
            return []
        out: list[HistoryEntry] = []
        with open(self._file, "r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    out.append(HistoryEntry(**json.loads(line)))
                except Exception:  # noqa: BLE001
                    continue
        return list(reversed(out))

    def clear(self) -> None:
        if os.path.isfile(self._file):
            os.remove(self._file)
