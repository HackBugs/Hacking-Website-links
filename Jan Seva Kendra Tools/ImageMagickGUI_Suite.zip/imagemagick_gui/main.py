"""
ImageMagick GUI Suite
=====================
A professional, modular Windows desktop GUI for ImageMagick.
Run with:  python main.py
"""
import sys

from PySide6.QtWidgets import QApplication

from ui.main_window import MainWindow


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("ImageMagick GUI Suite")
    app.setOrganizationName("ImageMagickGUI")
    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
