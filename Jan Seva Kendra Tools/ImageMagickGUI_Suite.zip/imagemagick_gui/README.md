# ImageMagick GUI Suite

A graphical, Windows-friendly desktop front-end for ImageMagick. No CMD
knowledge required: drag in files, pick a tool from the sidebar, click
Start.

Built with **Python 3.11+ and PySide6 (Qt 6)**, calling the `magick`
executable through safe, argument-list subprocess calls (never a shell
string — filenames with spaces/unicode and command injection are handled
correctly).

---

## 1. Requirements

- **Windows 10/11, 64-bit** (also runs on Linux/macOS for development —
  only the packaging step below is Windows-specific)
- **Python 3.11 or newer** — https://www.python.org/downloads/
- **ImageMagick 7** (the current Windows installer ships the unified
  `magick.exe` this app expects) — https://imagemagick.org/script/download.php
  - During install, tick **"Install legacy utilities (e.g. convert)"** is
    not required, but ticking **"Add application directory to your
    system path"** is recommended so auto-detection finds it immediately.

## 2. Setup (first time)

```bash
# from the project folder
python -m venv .venv
.venv\Scripts\activate          # Windows
# source .venv/bin/activate     # macOS/Linux

pip install -r requirements.txt
```

## 3. Run

```bash
python main.py
```

On first launch the app auto-detects ImageMagick. If it isn't found, use
**Home → "Select executable manually…"** (or the **Settings** page) to
point it at `magick.exe`, then click **Test**.

## 4. Using the app

1. Go to **Batch Converter**, drag in files or a folder (or `Ctrl+O` /
   `Ctrl+Shift+O`).
2. Switch to any tool tab on the left (Resize, PDF Tools, Compression,
   Watermark, …) — every tool operates on the same shared queue.
3. Configure the options, choose an output folder, click **Start**
   (`Ctrl+Enter`). `Esc` cancels a running batch.
4. A results dialog shows Completed / Failed / Skipped counts with
   per-file details. Everything is also logged on the **History** page.

### Example: 96 photos → one properly-oriented A4 PDF
Batch Converter → add the 96 JPGs → **PDF Tools → Images → PDF** → Page
size `A4`, Orientation `AUTO`, Fit mode `fit`, DPI `150` → **Create PDF**.
Portrait photos stay portrait, landscape photos stay landscape, and
nothing is stretched — this exact scenario is covered by the test suite
below.

## 5. Project structure

```
main.py                     Entry point
core/
  imagemagick_service.py    Detection + safe process execution
  pdf_service.py            Image<->PDF, orientation-safe page assembly
  file_utils.py             Natural sort, naming templates, folder scan
  worker.py                 Background QThread batch runner + cancellation
  settings_service.py       JSON settings persistence
  preset_service.py         Preset create/edit/duplicate/import/export
  history_service.py        Operation history log
ui/
  main_window.py            Sidebar navigation + shared file queue
  batch_widget.py           Drag-and-drop file table with thumbnails
  common.py                 Output-options widget, run/progress controls
  pages_transform.py        Resize, Crop, Rotate, Compression, Adjustments, Filters
  pages_pdf.py               Images→PDF, PDF→Images
  pages_extra.py            Watermark, Advanced builder, Home, History, Settings
presets/                    Sample preset JSON files (also auto-created on first run)
tests/
  test_core.py              Automated tests (see below)
```

Architecture follows the brief's separation of concerns: UI code never
calls `subprocess` directly — everything goes through `core/*` services,
so the processing logic is testable independent of the GUI.

## 6. Automated tests

```bash
pip install pytest
pytest tests/ -v
```

Covers: JPG→PNG, PNG→JPG, JPG→PDF, multi-image→PDF, **portrait JPEG with
EXIF rotation stays portrait**, mixed portrait/landscape PDF, resize,
crop, compression, an invalid/corrupt image, natural sort ordering, and
unicode/space-containing filenames. (`tests/test_core.py` documents which
of the spec's section-40 test list are automated vs. left as manual QA —
UI-driven cases like drag-and-drop and cancellation mid-batch need a
running Qt event loop and are best exercised by hand.)

## 7. Packaging a standalone Windows build (optional)

This repository does not include a prebuilt `.exe` — building one
requires a Windows machine (PyInstaller doesn't cross-compile from
Linux/macOS to Windows). On Windows:

```bash
pip install pyinstaller
pyinstaller --noconsole --onedir --name ImageMagickGUI main.py
```

This produces `dist/ImageMagickGUI/ImageMagickGUI.exe`. For a proper
installer with Start Menu/Desktop shortcuts and an uninstaller, feed that
`dist/ImageMagickGUI` folder into a tool such as
[Inno Setup](https://jrsoftware.org/isinfo.php) (free) or the WiX Toolset
(MSIX/MSI). ImageMagick itself is not bundled — the app expects it to be
installed separately (or you can point users at the portable ZIP build
of ImageMagick and let them select it manually via Settings).

## 8. Known limitations / what's intentionally left out of this build

To keep this a real, tested deliverable rather than a much larger amount
of unverified code, the following items from the original spec are
**not** implemented yet:

- Visual crop handles / draggable selection in the preview panel (the
  Crop tool is numeric X/Y/W/H only for now)
- OCR integration (no engine wired in; `core/` is organized so a
  `core/ocr_service.py` could be added following the same pattern as
  `pdf_service.py` without touching other modules)
- HEIC/HEIF input is supported only if your installed ImageMagick build
  has the delegate compiled in (`Settings` doesn't currently surface a
  per-format capability list, though `ImageMagickService.supports_delegate()`
  exists for this and can be wired into a page)
- Deskew / background cleanup in Scan mode (the "Scan to PDF" preset
  exists, but deskew is not yet applied automatically)
- A polished light/dark Qt stylesheet is included, but it's functional
  rather than pixel-perfect "commercial app" styling
- No MSIX/EXE installer is built here (see section 7)

Everything else described in the brief — batch processing, thumbnails,
natural sort, custom naming templates, resize/crop/rotate/flip,
compression with size-reduction reporting, adjustments, 16 filter
effects, text and logo watermarking, the orientation-safe PDF
create/extract pipeline, the safe advanced command builder, presets,
settings, history, background processing with cancellation, and
structured error handling — is implemented and was tested against a real
ImageMagick backend (see section 6).
