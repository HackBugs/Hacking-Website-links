"""
tests/test_core.py
-------------------
Automated tests for the non-UI core logic (spec section 40). Run with:

    pytest tests/ -v

Tests that need a real ImageMagick executable are skipped automatically if
`magick` (or a compatible shim) is not found on PATH, so this suite also
runs in pure-logic CI environments.
"""
from __future__ import annotations

import os
import shutil
import sys
import tempfile

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from core.file_utils import (
    natural_sort_key, render_name_template, unique_output_path, human_size, scan_folder,
)
from core.imagemagick_service import ImageMagickService, sanitize_custom_args
from core.pdf_service import PdfService, PdfPageOptions

MAGICK_AVAILABLE = shutil.which("magick") is not None
needs_magick = pytest.mark.skipif(not MAGICK_AVAILABLE, reason="ImageMagick ('magick') not found on PATH")


# --------------------------------------------------------------- file_utils
def test_natural_sort_order():
    names = ["img10.jpg", "img2.jpg", "img1.jpg", "img11.jpg"]
    assert sorted(names, key=natural_sort_key) == ["img1.jpg", "img2.jpg", "img10.jpg", "img11.jpg"]


def test_render_name_template_index_padding():
    assert render_name_template("{index}_{name}", 1, "photo.jpg") == "001_photo"
    assert render_name_template("page_{index}", 42, "x.png") == "page_042"


def test_render_name_template_preserves_original_name_token():
    assert render_name_template("{name}", 5, "IMG_2024.HEIC") == "IMG_2024"


def test_human_size_formats():
    assert human_size(500) == "500 B"
    assert "KB" in human_size(2048)
    assert "MB" in human_size(5 * 1024 * 1024)


def test_unique_output_path_rename_on_collision(tmp_path):
    existing = tmp_path / "out.jpg"
    existing.write_bytes(b"x")
    result = unique_output_path(str(existing), policy="Rename")
    assert result != str(existing)
    assert not os.path.exists(result)


def test_unique_output_path_skip_returns_none(tmp_path):
    existing = tmp_path / "out.jpg"
    existing.write_bytes(b"x")
    assert unique_output_path(str(existing), policy="Skip") is None


def test_unique_output_path_overwrite_returns_same(tmp_path):
    existing = tmp_path / "out.jpg"
    existing.write_bytes(b"x")
    assert unique_output_path(str(existing), policy="Overwrite") == str(existing)


def test_scan_folder_filters_unsupported_and_sorts(tmp_path):
    (tmp_path / "b.jpg").write_bytes(b"x")
    (tmp_path / "a.png").write_bytes(b"x")
    (tmp_path / "notes.txt").write_bytes(b"x")
    result = scan_folder(str(tmp_path))
    assert all(f.endswith((".jpg", ".png")) for f in result)
    assert len(result) == 2


def test_scan_folder_unicode_and_spaces(tmp_path):
    weird = tmp_path / "Ünïcødé Ñame with spaces.jpg"
    weird.write_bytes(b"x")
    result = scan_folder(str(tmp_path))
    assert str(weird) in result


# ----------------------------------------------------------- custom args
def test_sanitize_custom_args_strips_shell_metacharacters():
    args, warnings = sanitize_custom_args("-resize 800x600 && rm -rf /")
    assert "&&" not in " ".join(args)
    assert warnings, "expected a warning about the stripped sequence"


def test_sanitize_custom_args_allows_normal_flags():
    args, warnings = sanitize_custom_args("-auto-orient -resize 1600x1600 -quality 85")
    assert args == ["-auto-orient", "-resize", "1600x1600", "-quality", "85"]
    assert not warnings


# -------------------------------------------------------- ImageMagick service
@needs_magick
def test_imagemagick_autodetect_and_version():
    svc = ImageMagickService()
    info = svc.autodetect()
    assert info.ok
    assert info.version


@needs_magick
def test_imagemagick_rejects_bad_path():
    svc = ImageMagickService()
    info = svc.set_path("/path/does/not/exist/magick")
    assert not info.ok


@needs_magick
def test_missing_executable_reports_error(tmp_path):
    svc = ImageMagickService()
    fake = tmp_path / "not_magick"
    fake.write_text("not an executable")
    info = svc.set_path(str(fake))
    assert not info.ok


# --------------------------------------------------------------- image ops
@pytest.fixture
def sample_images(tmp_path):
    svc = ImageMagickService()
    svc.autodetect()
    portrait = tmp_path / "portrait.jpg"
    landscape = tmp_path / "landscape.jpg"
    svc.run(["convert", "-size", "400x600", "xc:skyblue", str(portrait)])
    svc.run(["convert", "-size", "600x400", "xc:salmon", str(landscape)])
    return svc, str(portrait), str(landscape)


@needs_magick
def test_jpg_to_png(sample_images):
    svc, portrait, _ = sample_images
    out = portrait.replace(".jpg", ".png")
    res = svc.run(["convert", portrait, out])
    assert res.ok and os.path.isfile(out)


@needs_magick
def test_png_to_jpg(sample_images, tmp_path):
    svc, portrait, _ = sample_images
    png_path = str(tmp_path / "temp.png")
    svc.run(["convert", portrait, png_path])
    jpg_out = str(tmp_path / "back.jpg")
    res = svc.run(["convert", png_path, jpg_out])
    assert res.ok and os.path.isfile(jpg_out)


@needs_magick
def test_resize_preserves_aspect_ratio(sample_images, tmp_path):
    svc, portrait, _ = sample_images
    out = str(tmp_path / "resized.jpg")
    res = svc.run(["convert", portrait, "-resize", "200x200", out])
    assert res.ok
    ident = svc.identify(out)
    w, h = int(ident.stdout.split("|")[0]), int(ident.stdout.split("|")[1])
    assert w <= 200 and h <= 200
    assert abs((w / h) - (400 / 600)) < 0.05


@needs_magick
def test_crop(sample_images, tmp_path):
    svc, portrait, _ = sample_images
    out = str(tmp_path / "cropped.jpg")
    res = svc.run(["convert", portrait, "-crop", "100x100+0+0", "+repage", out])
    assert res.ok
    ident = svc.identify(out)
    w, h = int(ident.stdout.split("|")[0]), int(ident.stdout.split("|")[1])
    assert (w, h) == (100, 100)


@needs_magick
def test_compression_reduces_size(sample_images, tmp_path):
    svc, portrait, _ = sample_images
    out = str(tmp_path / "compressed.jpg")
    svc.run(["convert", portrait, "-quality", "95", str(tmp_path / "hi.jpg")])
    svc.run(["convert", portrait, "-strip", "-quality", "20", out])
    hi_size = os.path.getsize(tmp_path / "hi.jpg")
    lo_size = os.path.getsize(out)
    assert lo_size <= hi_size


@needs_magick
def test_invalid_image_reports_failure(tmp_path):
    svc = ImageMagickService()
    svc.autodetect()
    bad = tmp_path / "bad.jpg"
    bad.write_bytes(b"this is not an image")
    out = str(tmp_path / "out.jpg")
    res = svc.run(["convert", str(bad), out])
    assert not res.ok  # must fail gracefully, not crash the caller


# -------------------------------------------------------------------- PDF
@needs_magick
def test_jpg_to_pdf(sample_images, tmp_path):
    svc, portrait, _ = sample_images
    pdf_service = PdfService(svc)
    out_pdf = str(tmp_path / "single.pdf")
    opts = PdfPageOptions(page_size="A4", orientation="AUTO", fit_mode="fit", dpi=100)
    pdf_service.images_to_pdf([portrait], out_pdf, opts, tmp_dir=str(tmp_path / "build"))
    assert os.path.isfile(out_pdf)


@needs_magick
def test_multiple_jpg_to_pdf(sample_images, tmp_path):
    svc, portrait, landscape = sample_images
    pdf_service = PdfService(svc)
    out_pdf = str(tmp_path / "multi.pdf")
    opts = PdfPageOptions(page_size="A4", orientation="AUTO", fit_mode="fit", dpi=100)
    pdf_service.images_to_pdf([portrait, landscape], out_pdf, opts, tmp_dir=str(tmp_path / "build2"))
    assert os.path.isfile(out_pdf)


@needs_magick
def test_mixed_portrait_landscape_pdf_keeps_each_page_orientation(sample_images, tmp_path):
    """
    The specific regression this whole application exists to prevent:
    a portrait photo must not silently become a landscape PDF page.
    We verify by rendering each page back to a raster image (via ImageMagick
    itself, one page at a time) and checking width/height per page.
    """
    svc, portrait, landscape = sample_images
    pdf_service = PdfService(svc)
    out_pdf = str(tmp_path / "mixed.pdf")
    opts = PdfPageOptions(page_size="A4", orientation="AUTO", fit_mode="fit", dpi=100)
    pdf_service.images_to_pdf([portrait, landscape], out_pdf, opts, tmp_dir=str(tmp_path / "build3"))

    page0 = str(tmp_path / "page0.png")
    page1 = str(tmp_path / "page1.png")
    svc.run(["convert", "-density", "72", f"{out_pdf}[0]", page0])
    svc.run(["convert", "-density", "72", f"{out_pdf}[1]", page1])

    ident0 = svc.identify(page0)
    ident1 = svc.identify(page1)
    w0, h0 = int(ident0.stdout.split("|")[0]), int(ident0.stdout.split("|")[1])
    w1, h1 = int(ident1.stdout.split("|")[0]), int(ident1.stdout.split("|")[1])

    assert h0 >= w0, "page 1 (from a portrait source) must remain portrait"
    assert w1 >= h1, "page 2 (from a landscape source) must remain landscape"


@needs_magick
def test_pdf_to_images_page_count(sample_images, tmp_path):
    svc, portrait, landscape = sample_images
    pdf_service = PdfService(svc)
    out_pdf = str(tmp_path / "for_extract.pdf")
    opts = PdfPageOptions(page_size="A4", orientation="AUTO", fit_mode="fit", dpi=100)
    pdf_service.images_to_pdf([portrait, landscape], out_pdf, opts, tmp_dir=str(tmp_path / "build4"))

    out_dir = str(tmp_path / "extracted")
    outputs = pdf_service.pdf_to_images(out_pdf, out_dir, "jpg", dpi=100, quality=85,
                                         naming_template="page_{index}")
    assert len(outputs) == 2
    assert all(os.path.isfile(p) for p in outputs)


@needs_magick
def test_existing_output_file_rename_policy(sample_images, tmp_path):
    svc, portrait, _ = sample_images
    out = tmp_path / "dup.jpg"
    svc.run(["convert", portrait, str(out)])
    renamed = unique_output_path(str(out), policy="Rename")
    assert renamed != str(out)


@needs_magick
def test_special_characters_and_spaces_in_filenames(sample_images, tmp_path):
    svc, portrait, _ = sample_images
    weird_dir = tmp_path / "folder with spaces & (symbols)"
    weird_dir.mkdir()
    weird_src = weird_dir / "photo #1 [final].jpg"
    shutil.copy(portrait, weird_src)
    out = weird_dir / "output ünïcode.jpg"
    res = svc.run(["convert", str(weird_src), str(out)])
    assert res.ok and out.is_file()
